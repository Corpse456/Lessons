package by.bsuir.ios.pokertrainer.entity;

public enum UserRole {
	User
}
