package by.bsuir.ios.pokertrainer.dao;

import by.bsuir.ios.pokertrainer.entity.Question;

public interface QuestionDAO extends BaseDAO<Integer, Question> {

}
