package lesson90.app.model;

public enum Temperament {

    AS_VEGETABLE, MELANCHOLYC, CALM, HORNY, AGRESSIVE

}
