package lesson90.app.model;

public class ElephantPersonality {

    private Temperament temperament;
    private int iq;

    public Temperament getTemperament () {
        return temperament;
    }

    public void setTemperament (Temperament temperament) {
        this.temperament = temperament;
    }

    public int getIq () {
        return iq;
    }

    public void setIq (int iq) {
        this.iq = iq;
    }
}
