package com.simple;

public class HibernateUser {

    public static void main (String[] args) {
        //SessionFactory hibernateSession;
    }
}
