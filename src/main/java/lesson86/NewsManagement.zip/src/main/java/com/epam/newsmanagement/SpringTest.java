package com.epam.newsmanagement;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.epam.newsmanagement.exception.ServiceException;
import com.epam.newsmanagement.service.impl.NewsManagementServiceImpl;

public class SpringTest {

    public static void main (String[] args) throws ServiceException {
        ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext();
        NewsManagementServiceImpl newsSv = (NewsManagementServiceImpl) ctx.getBean("NewsManagementServiceImpl");
        newsSv.loadAllNews();
        ctx.close();
    }
}
