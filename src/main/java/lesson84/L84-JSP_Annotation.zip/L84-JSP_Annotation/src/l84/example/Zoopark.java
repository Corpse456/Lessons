package l84.example;

@Mammal
public class Zoopark {
	
	@Mammal
	String ziraf = "vasya";
	
	
	//@Mammal нельзя, Таргет.Метод не стоит
	public static void main(String[] args) {
		
	}

}
