package com.mtvnet.dss.ivi.delivery.dto.ids;

import com.mtvnet.dss.ivi.delivery.dto.ids.ws.ResponseCode;
import com.mtvnet.dss.ivi.delivery.exception.IviDeliveryServiceException;
import lombok.Getter;

public enum ArcStage {

    AUTHORING("authoring"), LIVE("live");

    @Getter
    private final String name;

    ArcStage(String name) {
        this.name = name;
    }

    public static ArcStage fromName(String name) {
        for (ArcStage stage : ArcStage.values()) {
            if (stage.name.equals(name)) {
                return stage;
            }
        }
        throw new IviDeliveryServiceException("No Arc stage mapped to the name = " + name,
                ResponseCode.INVALID_ARC_STAGE);
    }

}
