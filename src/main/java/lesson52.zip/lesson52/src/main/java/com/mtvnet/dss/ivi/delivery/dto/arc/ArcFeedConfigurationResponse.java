package com.mtvnet.dss.ivi.delivery.dto.arc;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ArcFeedConfigurationResponse {

    @Valid
    @NotNull
    private Response response;
    private Summary summary;

}
