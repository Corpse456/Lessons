package com.mtvnet.dss.ivi.delivery.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.zip.GZIPInputStream;

import org.springframework.util.FileCopyUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public final class IviJobHttpUtils {

    private static final String CONTENT_TYPE_GZIP = "application/gzip";
    private static final String CONTENT_TYPE_XML = "application/xml";

    public static void downloadBviFeed(File file, URL downloadUrl) throws IOException {
        log.debug("Starting download from " + downloadUrl + " to " + file.getAbsolutePath());
        File downloadedFile = new File(file.getAbsolutePath() + ".download");
        downloadedFile = downloadFileByUrl(downloadUrl, downloadedFile);
        downloadedFile.renameTo(file);
    }

    private static File downloadFileByUrl(URL downloadUrl, File downloadedFile) throws IOException {
        URLConnection connection = downloadUrl.openConnection();
        connection.setRequestProperty("Accept-Encoding", "gzip");
        InputStream in = connection.getInputStream();
        OutputStream out = new FileOutputStream(downloadedFile, false);
        FileCopyUtils.copy(in, out); // streams are closed inside

        downloadedFile = processDownloadBasedOnContentType(downloadedFile, connection);
        return downloadedFile;
    }

    private static File processDownloadBasedOnContentType(File downloadedFile, URLConnection connection)
            throws IOException {
        String contentType = connection.getContentType();
        log.debug("Fep response type while downloading BVI feed is: " + contentType);
        if (CONTENT_TYPE_GZIP.equals(contentType)) {
            File gzipFIle = new File(downloadedFile.getAbsolutePath() + ".gz");
            downloadedFile.renameTo(gzipFIle);
            downloadedFile = ungzipContentAndDeleteGZip(gzipFIle);
        } else if (!CONTENT_TYPE_XML.equals(contentType)) {
            String errorMessage = "BVI feed content type expected to be gzip or xml. But received content is: "
                    + contentType;
            log.error(errorMessage);
            throw new RuntimeException(errorMessage);
        }
        return downloadedFile;
    }

    private static File ungzipContentAndDeleteGZip(File gzipFile) throws IOException {
        String zipFileName = gzipFile.getAbsolutePath();
        String contentFileName = zipFileName.substring(0, zipFileName.lastIndexOf("."));
        File contentFile = new File(contentFileName);
        InputStream in = new GZIPInputStream(new FileInputStream(gzipFile.getAbsolutePath()));
        OutputStream out = new FileOutputStream(contentFile, false);
        FileCopyUtils.copy(in, out); // streams are closed inside
        gzipFile.delete();
        log.debug("Successfully unpacked gzipped response.");
        return contentFile;
    }

}
