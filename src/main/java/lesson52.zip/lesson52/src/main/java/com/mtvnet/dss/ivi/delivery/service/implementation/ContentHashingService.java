package com.mtvnet.dss.ivi.delivery.service.implementation;

import com.mtvnet.dss.ivi.delivery.dto.fep.BviVideoDocument;
import com.mtvnet.dss.ivi.delivery.dto.ids.ws.ResponseCode;
import com.mtvnet.dss.ivi.delivery.exception.IviDeliveryServiceException;
import com.mtvnet.dss.ivi.delivery.service.IContentHashingService;
import org.springframework.stereotype.Component;
import org.springframework.util.DigestUtils;

import java.io.UnsupportedEncodingException;

/**
 * Concrete implementation of {@link IContentHashingService}, using MD5 as a hash function on a provided XML content.
 */
@Component
public class ContentHashingService implements IContentHashingService {

    @Override
    public String calculateContentHash(BviVideoDocument videoDocument) {
        try {
            return DigestUtils.md5DigestAsHex(videoDocument.getHashXmlString().getBytes("UTF-8"));
        } catch (UnsupportedEncodingException e) {
            throw new IviDeliveryServiceException(e, ResponseCode.IDS_UNCLASSIFIED_ERROR);
        }
    }

}
