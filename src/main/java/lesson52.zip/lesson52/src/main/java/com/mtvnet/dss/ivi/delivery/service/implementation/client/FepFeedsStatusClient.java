package com.mtvnet.dss.ivi.delivery.service.implementation.client;

import com.mtvnet.dss.ivi.delivery.dto.fep.FeedStatusElement;
import com.mtvnet.dss.ivi.delivery.dto.fep.FepFeedsStatusResponse;
import com.mtvnet.dss.ivi.delivery.dto.ids.FeedEnvironment;
import com.mtvnet.dss.ivi.delivery.dto.ids.ws.ResponseCode;
import com.mtvnet.dss.ivi.delivery.exception.ThirdPartySystemAccessException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.net.URL;
import java.util.List;

@Component
@Slf4j
public class FepFeedsStatusClient {

    @Autowired
    private FepEnvironmentSpecificUrlBuilder fepEnvironmentSpecificUrlBuilder;

    @Value("${ivi.service.fep.allfeeds.url.path}")
    private String statusEndpointPath;

    @Autowired
    private RestTemplate restTemplate;

    public List<FeedStatusElement> feedStatusListForFeedEnvironment(FeedEnvironment feedEnvironment) {
        URL fepStatusEndpoint = fepStatusEndpointForFeedEnvironment(feedEnvironment);
        log.debug("Checking status of all Freewheel feeds at URL: {}", fepStatusEndpoint);
        return query(fepStatusEndpoint);
    }

    private URL fepStatusEndpointForFeedEnvironment(FeedEnvironment feedEnvironment) {
        return fepEnvironmentSpecificUrlBuilder.environmentSpecificFepUrl(feedEnvironment, statusEndpointPath);
    }

    private List<FeedStatusElement> query(URL fepStatusEndpoint) {
        try {
            return restTemplate.getForObject(fepStatusEndpoint.toString(), FepFeedsStatusResponse.class)
                    .getStatusList();
        } catch (RestClientException e) {
            throw new ThirdPartySystemAccessException(e, ResponseCode.THIRDPARTY_SYSTEM_UNCLASSIFIED_ERROR);
        }
    }

}
