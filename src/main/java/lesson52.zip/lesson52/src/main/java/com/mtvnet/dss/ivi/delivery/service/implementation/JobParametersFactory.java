package com.mtvnet.dss.ivi.delivery.service.implementation;

import com.mtvnet.dss.ivi.delivery.dto.ids.FeedIngestionTask;
import com.mtvnet.dss.ivi.delivery.service.IJobParametersFactory;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import java.util.HashMap;
import java.util.Map;

import static com.mtvnet.dss.ivi.delivery.batch.BatchConfigurationConstants.*;

@Component
public class JobParametersFactory implements IJobParametersFactory {

    @Override
    public JobParameters createJobParameters(FeedIngestionTask feedIngestionTask) {
        Assert.notNull(feedIngestionTask, "feedIngestionTask expected to be not null");
        Map<String, JobParameter> parameters = new HashMap<>();
        parameters.put(JOB_PARAMETER_FREEWHEEL_NETWORK,
                parameter(feedIngestionTask.getFreeWheelNetwork().getAsJobParameter()));
        parameters.put(JOB_PARAMETER_FEED_ENVIRONMENT, parameter(feedIngestionTask.getFeedEnvironment()
                .getName()));
        parameters.put(JOB_PARAMETER_CATEGORY_NAME, parameter(feedIngestionTask.getCategory()));
        parameters.put(JOB_PARAMETER_SITE_NAME, parameter(feedIngestionTask.getSiteName()));
        parameters.put(JOB_PARAMETER_FEED_NAME, parameter(feedIngestionTask.getFeedName()));
        parameters.put(JOB_PARAMETER_FEED_PARAM_SHORT_ID, parameter(feedIngestionTask.getFeedParamShortId()));
        parameters.put(JOB_PARAMETER_FEED_GEN_TIMESTAMP, parameter(feedIngestionTask.getFeedGenTimestamp()));
        return new JobParameters(parameters);
    }

    private JobParameter parameter(String value) {
        return new JobParameter(value);
    }

}
