package com.mtvnet.dss.ivi.delivery.batch.scheduler;

import com.mtvnet.dss.ivi.delivery.dto.ids.FeedEnvironment;
import com.mtvnet.dss.ivi.delivery.dto.ids.FeedIngestionTask;
import com.mtvnet.dss.ivi.delivery.service.IIngestionTaskDispatcher;
import com.mtvnet.dss.ivi.delivery.service.IIngestionTasksSupplier;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@ConditionalOnProperty("ivi.service.scheduler.enabled")
@Slf4j
public class IviJobScheduler {

    @Autowired
    private IIngestionTaskDispatcher ingestionTaskDispatcher;

    @Autowired
    private IIngestionTasksSupplier ingestionTasksSupplier;

    @Value("${ivi.service.fep.defaultEnvironment}")
    private FeedEnvironment defaultFeedEnvironment;

    @Scheduled(cron = "${ivi.service.scheduler.cronExpression}")
    public void queueFeedsToDeliveryJob() {
        log.debug("Job scheduler triggered");
        List<FeedIngestionTask> feedIngestionTasks =
                ingestionTasksSupplier.requestPendingIngestionTasksFor(defaultFeedEnvironment);
        logFeedCheckResults(feedIngestionTasks);
        for (FeedIngestionTask feedIngestionTask : feedIngestionTasks) {
            ingestionTaskDispatcher.dispatchIngestion(feedIngestionTask);
        }
    }

    private void logFeedCheckResults(List<FeedIngestionTask> feedIngestionTasks) {
        if (feedIngestionTasks.size() > 0) {
            log.info("Scheduled feeds check returned new IVI feeds to delivery, list size is: {}",
                    feedIngestionTasks.size());
        } else {
            log.debug("Scheduled feeds check returned empty IVI feeds list, nothing to update.");
        }
    }
}
