package com.mtvnet.dss.ivi.delivery.service.implementation;

import com.mtvnet.dss.ivi.delivery.dto.fep.FeedStatusElement;
import com.mtvnet.dss.ivi.delivery.dto.ids.ArcFeedConfiguration;
import com.mtvnet.dss.ivi.delivery.dto.ids.FeedEnvironment;
import com.mtvnet.dss.ivi.delivery.dto.ids.FeedIngestionTask;
import com.mtvnet.dss.ivi.delivery.dto.ids.FreeWheelNetwork;
import com.mtvnet.dss.ivi.delivery.dto.ids.ws.ResponseCode;
import com.mtvnet.dss.ivi.delivery.exception.ArcFeedConfigurationException;
import com.mtvnet.dss.ivi.delivery.exception.IviDeliveryServiceException;
import com.mtvnet.dss.ivi.delivery.service.IArcFeedConfigurationService;
import com.mtvnet.dss.ivi.delivery.service.IFepFeedsStatusService;
import com.mtvnet.dss.ivi.delivery.service.IIngestionTasksSupplier;
import com.mtvnet.dss.ivi.delivery.service.IJobParametersFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.validation.Validator;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.mtvnet.dss.ivi.delivery.batch.BatchConfigurationConstants.FAIL_EXECUTION_STATUSES;
import static com.mtvnet.dss.ivi.delivery.batch.BatchConfigurationConstants.IVI_DELIVERY_JOB_NAME;

@Component
@Slf4j
public class IngestionTasksSupplier implements IIngestionTasksSupplier {

    @Autowired
    private IArcFeedConfigurationService arcFeedConfigurationService;

    @Autowired
    private IFepFeedsStatusService fepFeedsStatusService;

    @Autowired
    private Validator validator;

    @Value("${ivi.service.job.sameFeedMaxRetryAttempts}")
    private int maxJobRetryAttempts;

    @Autowired
    private JobExplorer jobExplorer;

    @Autowired
    private JobRepository jobRepository;

    @Autowired
    private IJobParametersFactory jobParametersFactory;

    @Override
    public List<FeedIngestionTask> requestPendingIngestionTasksFor(FeedEnvironment feedEnvironment) {
        return fepFeedsStatusService.retrieveFreeWheelFeedStatusList(feedEnvironment).stream()
                .flatMap(feedStatus -> createTasksPerFreeWheelNetwork(feedEnvironment, feedStatus))
                .filter(this::thisFeedShouldBeDelivered)
                .collect(Collectors.toList());
    }

    @Override
    public FeedIngestionTask requestIngestionTaskFor(FeedEnvironment feedEnvironment, FreeWheelNetwork freeWheelNetwork,
                                                     String feedName, String feedParam) {
        FeedStatusElement feedStatus = fepFeedsStatusService
                .retrieveFreeWheelFeedStatus(feedEnvironment, feedName, feedParam);

        String arcSite = queryConfiguration(feedEnvironment, feedName).getSite();

        return createFeedIngestionTask(feedEnvironment, feedStatus, freeWheelNetwork, arcSite);
    }

    private Stream<FeedIngestionTask> createTasksPerFreeWheelNetwork(FeedEnvironment feedEnvironment,
                                                                     FeedStatusElement feedStatus) {
        Stream<FeedIngestionTask> feedIngestionTasks = Stream.empty();
        if (feedStatus != null) {
            feedIngestionTasks = createTasksPerFreeWheelNetworkWithSafeArcCall(feedEnvironment, feedStatus).stream();
        }
        return feedIngestionTasks;
    }

    /**
     * Creates separate {@link FeedIngestionTask} for each FreeWheel network configured in Arc.
     * <b>Note on exception handling:</b>any {@link IviDeliveryServiceException} catched is logged, but not propagated
     * to caller as we don't want to stop entire delivery process for a single feed configured in a wrong way (or a
     * single failed Arc call), thus "safe Arc call" part of method name.
     *
     * @param feedEnvironment feed environment IDS is operating on,
     * @param feedStatus      feed status to query related Arc configuration.
     * @return list of feed ingestion tasks, or empty list in case of any {@link IviDeliveryServiceException}.
     */
    private List<FeedIngestionTask> createTasksPerFreeWheelNetworkWithSafeArcCall(FeedEnvironment feedEnvironment,
                                                                                  FeedStatusElement feedStatus) {
        List<FeedIngestionTask> feedIngestionTasks;
        try {
            ArcFeedConfiguration arcFeedConfiguration =
                    queryConfiguration(feedEnvironment, feedStatus.getFeedSchedule().getFeedName());

            String arcSite = arcFeedConfiguration.getSite();

            feedIngestionTasks = arcFeedConfiguration.getFreeWheelNetworks().stream()
                    .map(network -> createFeedIngestionTask(feedEnvironment, feedStatus, network, arcSite))
                    .collect(Collectors.toList());
        } catch (ArcFeedConfigurationException e) {
            log.error("Invalid Arc feed configuration: {}", e.getMessage());
            feedIngestionTasks = Collections.emptyList();
        } catch (IviDeliveryServiceException e) {
            log.error("Exception encountered while querying Arc!", e);
            feedIngestionTasks = Collections.emptyList();
        }
        return feedIngestionTasks;
    }

    private FeedIngestionTask createFeedIngestionTask(FeedEnvironment feedEnvironment, FeedStatusElement feedStatus,
                                                      FreeWheelNetwork network, String site) {
        FeedIngestionTask feedIngestionTask = FeedIngestionTask.builder()
                .freeWheelNetwork(network)
                .feedEnvironment(feedEnvironment)
                .category(feedStatus.getFeedSchedule().getCategory())
                .siteName(determineSiteName(feedStatus, site))
                .feedName(feedStatus.getFeedSchedule().getFeedName())
                .feedParamShortId(feedStatus.getFeedSchedule().getParamShortId())
                .feedGenTimestamp(feedStatus.getFeedGenTimestamp())
                .build();
        if (!validator.validate(feedIngestionTask).isEmpty()) {
            log.error("Unable to create feed ingestion task for feed environment =  {}, feed status = {}, site = {}!",
                    feedEnvironment, feedStatus, site);
            throw new IviDeliveryServiceException("Failed to validate feed ingestion task: " + feedIngestionTask,
                    ResponseCode.INVALID_FEED_CONFIGURATION);
        }
        return feedIngestionTask;
    }

    private ArcFeedConfiguration queryConfiguration(FeedEnvironment feedEnvironment, String feedName) {
        return arcFeedConfigurationService.retrieveArcIngestionConfiguration(feedEnvironment, feedName);
    }


    private String determineSiteName(FeedStatusElement feedStatus, String arcSite) {
        Map<String, String> parameters = feedStatus.getFeedSchedule().getParameters() != null ?
                feedStatus.getFeedSchedule().getParameters() : Collections.emptyMap();
        return Stream.concat(
                Stream.of("ds.namespace", "namespace", "ds.endpoint", "endpoint").map(parameters::get),
                Stream.of(arcSite))
                .filter(((Predicate<String>) StringUtils::isEmpty).negate())
                .findFirst().orElse("shared");
    }

    private boolean thisFeedShouldBeDelivered(FeedIngestionTask feedIngestionTask) {
        JobParameters jobParameters = jobParametersFactory.createJobParameters(feedIngestionTask);
        JobExecution lastExecution = jobRepository.getLastJobExecution(IVI_DELIVERY_JOB_NAME, jobParameters);
        return feedDeliveryNeverStarted(lastExecution)
                || (feedStatusAllowsRetry(lastExecution) && !maxRetryAttemptsReached(lastExecution, feedIngestionTask));
    }

    private boolean feedStatusAllowsRetry(JobExecution lastExecution) {
        return FAIL_EXECUTION_STATUSES.contains(lastExecution.getStatus());
    }

    private boolean maxRetryAttemptsReached(JobExecution lastExecution, FeedIngestionTask feedIngestionTask) {
        boolean maxRetryAttemptsReached = jobExplorer.getJobExecutions(lastExecution.getJobInstance()).size() >=
                maxJobRetryAttempts;
        if (maxRetryAttemptsReached) {
            log.error("Feed {} generated at {} had too many unsuccessful delivery attempts and will be skipped until " +
                    "updated.", feedIngestionTask.getFeedName(), feedIngestionTask.getFeedGenTimestamp());
        }
        return maxRetryAttemptsReached;
    }

    private boolean feedDeliveryNeverStarted(JobExecution lastExecution) {
        return (lastExecution == null);
    }

}
