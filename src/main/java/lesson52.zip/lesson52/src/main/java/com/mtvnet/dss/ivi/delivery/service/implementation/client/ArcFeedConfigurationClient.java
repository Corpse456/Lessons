package com.mtvnet.dss.ivi.delivery.service.implementation.client;

import com.mtvnet.dss.ivi.delivery.dto.arc.ArcFeedConfigurationResponse;
import com.mtvnet.dss.ivi.delivery.dto.ids.ArcStage;
import com.mtvnet.dss.ivi.delivery.dto.ids.FeedEnvironment;
import com.mtvnet.dss.ivi.delivery.dto.ids.ws.ResponseCode;
import com.mtvnet.dss.ivi.delivery.exception.ThirdPartySystemAccessException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;

@Component
@Slf4j
public class ArcFeedConfigurationClient {

    @Autowired
    private RestTemplate restTemplate;

    @Value("${arc.request.urlParams.feedConfig}")
    private String feedConfigRequest;

    @Value("${arc.feedname.urlPlaceholder}")
    private String feedNamePlaceholder;

    @Value("${arc.defaultStage}")
    private ArcStage defaultArcStage;

    @Value("${arc.feedplatform.url}")
    private URI arcBaseUrl;

    public ArcFeedConfigurationResponse feedConfigurationByNameForFeedEnvironment(FeedEnvironment feedEnvironment,
                                                                                  String feedName) {
        URI uri = buildUri(feedName);
        log.debug("Sending Arc request as GET request: {}.", uri);
        return query(uri);
    }

    private URI buildUri(String feedName) {
        return UriComponentsBuilder.fromUri(arcBaseUrl)
                .queryParam("stage", defaultArcStage.getName())
                .queryParam("q", prepareQuery(feedName))
                .build().encode().toUri();
    }

    private String prepareQuery(String feedName) {
        return feedConfigRequest.replace(feedNamePlaceholder, feedName);
    }

    private ArcFeedConfigurationResponse query(URI uri) {
        try {
            return restTemplate.getForObject(uri, ArcFeedConfigurationResponse.class);
        } catch (RestClientException e) {
            throw new ThirdPartySystemAccessException(e, ResponseCode.THIRDPARTY_SYSTEM_UNCLASSIFIED_ERROR);
        }
    }

}
