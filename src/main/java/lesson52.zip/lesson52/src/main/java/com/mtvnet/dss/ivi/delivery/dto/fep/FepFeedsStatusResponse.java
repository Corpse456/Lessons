package com.mtvnet.dss.ivi.delivery.dto.fep;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class FepFeedsStatusResponse {

    @JsonProperty("status")
    private List<FeedStatusElement> statusList;

}
