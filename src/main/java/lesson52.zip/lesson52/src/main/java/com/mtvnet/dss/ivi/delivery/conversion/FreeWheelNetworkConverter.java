package com.mtvnet.dss.ivi.delivery.conversion;

import com.mtvnet.dss.ivi.delivery.dto.ids.FreeWheelNetwork;
import org.springframework.core.convert.converter.Converter;

public class FreeWheelNetworkConverter implements Converter<String, FreeWheelNetwork> {

    @Override
    public FreeWheelNetwork convert(String freeWheelNetworkName) {
        return FreeWheelNetwork.fromConfigProperty(freeWheelNetworkName);
    }

}
