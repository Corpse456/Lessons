package com.mtvnet.dss.ivi.delivery.service;

import com.mtvnet.dss.ivi.delivery.dto.fep.BviVideoDocument;
import com.mtvnet.dss.ivi.delivery.dto.fep.DeliveryStatus;

import java.util.List;

/**
 * Service class providing capabilities to track video document status with respect to delivery status and content
 * status checks.
 * <p>
 * <b>Note on exception handling:</b> concrete implementations should do its best to not throw any exceptions.
 * Delivery and content status checks are introduced to reduce load on external system (FreeWheel) and to prevent
 * multiple ingests of a same video document, but we still want to allow ingestion process to complete successfully
 * in case video document status storage is not available.
 * </p>
 */
public interface IBviVideoDocumentStatusStorageService {

    /**
     * Checks if a given video document awaits update.
     *
     * @param videoDocument video document to check if it awaits update.
     * @return true, if video document awaits update.
     */
    boolean awaitsUpdate(BviVideoDocument videoDocument);

    /**
     * Stores video document status for a given list of video documents associating passed delivery status with each
     * one.
     *
     * @param videoDocuments video documents to save status for,
     * @param deliveryStatus desired delivery status.
     */
    void storeVideoDocumentStatus(List<? extends BviVideoDocument> videoDocuments,
                                  DeliveryStatus deliveryStatus);

}
