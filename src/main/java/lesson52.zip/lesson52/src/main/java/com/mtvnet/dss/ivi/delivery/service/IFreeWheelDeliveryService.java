package com.mtvnet.dss.ivi.delivery.service;

import com.mtvnet.dss.ivi.delivery.dto.fep.BviVideoDocument;
import com.mtvnet.dss.ivi.delivery.dto.ids.FreeWheelNetwork;

import java.util.List;

/**
 * FreeWheel IVI API client.
 */
public interface IFreeWheelDeliveryService {

    /**
     * Synchronously performs the ingestion of a given feed to FreeWheel.
     *
     * @param items            feed items to ingest,
     * @param freeWheelNetwork network to perform ingest to.
     */
    void ingestIviDocuments(List<? extends BviVideoDocument> items, FreeWheelNetwork freeWheelNetwork);

    /**
     * Synchronously performs the ingestion of a given single-item feed to FreeWheel.
     *
     * @param iviItems         IVI items to ingest,
     * @param freeWheelNetwork network to perform ingest to.
     */
    void ingestIviDocuments(String iviItems, FreeWheelNetwork freeWheelNetwork);

}
