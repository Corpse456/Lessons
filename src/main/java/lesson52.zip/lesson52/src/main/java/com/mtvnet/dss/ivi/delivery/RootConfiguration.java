package com.mtvnet.dss.ivi.delivery;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.mtvnet.dss.ivi.delivery.utils.IviJobUtils;

@Configuration
@ComponentScan(basePackages = {"com.mtvnet.dss.ivi.delivery", "org.springframework.batch.admin"})
@EnableAutoConfiguration(exclude = {
        org.springframework.boot.autoconfigure.security.SecurityAutoConfiguration.class,
        org.springframework.boot.actuate.autoconfigure.ManagementWebSecurityAutoConfiguration.class})
@Import(value = {BatchConfiguration.class, WebConfiguration.class, FreeWheelOAuthConfiguration.class,
        ElastiCacheConfiguration.class, ConversionConfiguration.class})
@EnableScheduling
public class RootConfiguration extends SpringBootServletInitializer implements InitializingBean {

    @Autowired
    private Environment environment;

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder applicationBuilder) {
        return applicationBuilder.sources(RootConfiguration.class);
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        IviJobUtils.setStaticFreewheelXmlRootElement(environment.getProperty("ivi.service.job.support.mail"));
    }

}
