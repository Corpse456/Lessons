package com.mtvnet.dss.ivi.delivery.batch.implementation.marshalling;

import org.springframework.oxm.UnmarshallingFailureException;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.Characters;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;

class HashXmlStringConsumer implements Consumer<XMLEvent>, Supplier<String> {

    private static final int EXPECTED_BUFFER_LENGTH = 15;
    private static final QName DATUM_ITEM_NAME = QName.valueOf("datumItem");

    private final StringWriter hashXmlStringWriter = new StringWriter();

    private boolean doBufferWrites;
    private ArrayList<XMLEvent> buffer;

    @Override
    public void accept(XMLEvent xmlEvent) {
        if (xmlEvent.isStartElement() && DATUM_ITEM_NAME.equals(((StartElement) xmlEvent).getName())) {
            firstEventToBuffer(xmlEvent);
        } else if (xmlEvent.isEndElement() && DATUM_ITEM_NAME.equals(((EndElement) xmlEvent).getName())) {
            lastEventToBuffer(xmlEvent, this::shouldDropBuffer);
        } else {
            write(xmlEvent);
        }
    }

    private boolean shouldDropBuffer(List<XMLEvent> buffer) {
        return buffer.stream().anyMatch(event -> {
            String textContent = event.isCharacters() ? ((Characters) event).getData() : null;
            return "Trace ID".equals(textContent) || "Feed Name".equals(textContent);
        });
    }

    private void write(XMLEvent xmlEvent) {
        if (doBufferWrites) {
            buffer.add(xmlEvent);
        } else {
            try {
                xmlEvent.writeAsEncodedUnicode(hashXmlStringWriter);
            } catch (XMLStreamException e) {
                throw new UnmarshallingFailureException(e.getMessage(), e);
            }
        }
    }

    private void firstEventToBuffer(XMLEvent xmlEvent) {
        doBufferWrites(true);
        buffer = new ArrayList<>(EXPECTED_BUFFER_LENGTH);
        buffer.add(xmlEvent);
    }

    private void lastEventToBuffer(XMLEvent xmlEvent, Predicate<List<XMLEvent>> shouldDropBuffer) {
        doBufferWrites(false);
        if (!shouldDropBuffer.test(buffer)) {
            buffer.add(xmlEvent);
            buffer.forEach(this::write);
        }
        buffer = null;
    }

    private void doBufferWrites(boolean bufferWrites) {
        if (doBufferWrites == bufferWrites) {
            throw new UnmarshallingFailureException(
                    "The desired buffering state is the same as current, malformed XML?");
        }
        doBufferWrites = bufferWrites;
    }

    @Override
    public String get() {
        return hashXmlStringWriter.toString();
    }

}
