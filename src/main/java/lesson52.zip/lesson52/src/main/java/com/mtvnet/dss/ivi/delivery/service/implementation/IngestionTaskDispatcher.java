package com.mtvnet.dss.ivi.delivery.service.implementation;

import com.mtvnet.dss.ivi.delivery.batch.scheduler.FeedsDeliveryQueue;
import com.mtvnet.dss.ivi.delivery.dto.ids.FeedIngestionTask;
import com.mtvnet.dss.ivi.delivery.dto.ids.FreeWheelNetwork;
import com.mtvnet.dss.ivi.delivery.service.IIngestionTaskDispatcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class IngestionTaskDispatcher implements IIngestionTaskDispatcher {

    @Autowired
    private Map<FreeWheelNetwork, FeedsDeliveryQueue> networkQueues;

    @Override
    public void dispatchIngestion(FeedIngestionTask feedIngestionTask) {
        networkQueues.get(feedIngestionTask.getFreeWheelNetwork()).addFeed(feedIngestionTask);
    }

}
