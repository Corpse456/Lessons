package com.mtvnet.dss.ivi.delivery.service.implementation;

import com.google.common.util.concurrent.RateLimiter;
import com.mtvnet.dss.ivi.delivery.dto.ids.FreeWheelNetwork;
import com.mtvnet.dss.ivi.delivery.service.IRequestRateLimiter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.concurrent.ConcurrentHashMap;

@Component
public class RequestRateLimiter implements IRequestRateLimiter {

    private final ConcurrentHashMap<FreeWheelNetwork, RateLimiter> networkToRateLimiterMap =
            new ConcurrentHashMap<>();

    @Value("${freewheel.endpoint.requestsPerSecondPerNetworkLimit}")
    private long tpsLimit;

    @Override
    public void ensureRequestRateLimit(FreeWheelNetwork freeWheelNetwork) {
        networkToRateLimiterMap.computeIfAbsent(freeWheelNetwork, any -> RateLimiter.create(tpsLimit)).acquire();
    }

}
