package com.mtvnet.dss.ivi.delivery.dto.ids;

import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
@Builder
public class FeedIngestionTask {

    @NotNull
    private final FreeWheelNetwork freeWheelNetwork;
    @NotNull
    private final FeedEnvironment feedEnvironment;
    @NotNull
    private final String category;
    @NotNull
    private final String siteName;
    @NotNull
    private final String feedName;
    @NotNull
    private final String feedParamShortId;
    @NotNull
    private final String feedGenTimestamp;

}
