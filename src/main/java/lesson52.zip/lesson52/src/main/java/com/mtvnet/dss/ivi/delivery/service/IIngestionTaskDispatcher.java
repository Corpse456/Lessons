package com.mtvnet.dss.ivi.delivery.service;

import com.mtvnet.dss.ivi.delivery.dto.ids.FeedIngestionTask;

public interface IIngestionTaskDispatcher {

    void dispatchIngestion(FeedIngestionTask feedIngestionTask);

}
