package com.mtvnet.dss.ivi.delivery.conversion;

import com.mtvnet.dss.ivi.delivery.dto.ids.ArcStage;
import org.springframework.core.convert.converter.Converter;

public class ArcStageConverter implements Converter<String, ArcStage> {

    @Override
    public ArcStage convert(String arcStageName) {
        return ArcStage.fromName(arcStageName);
    }

}
