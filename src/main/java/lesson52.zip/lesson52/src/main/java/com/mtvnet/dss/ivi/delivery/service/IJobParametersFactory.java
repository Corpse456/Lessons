package com.mtvnet.dss.ivi.delivery.service;

import com.mtvnet.dss.ivi.delivery.dto.ids.FeedIngestionTask;
import org.springframework.batch.core.JobParameters;


/**
 * Factory responsible for creating job parameters for a given feed ingestion task.
 */
public interface IJobParametersFactory {

    /**
     * Creates job parameters for a given feed status.
     *
     * @param feedIngestionTask feed ingestion task.
     * @return job parameters matching provided feed status.
     */
    JobParameters createJobParameters(FeedIngestionTask feedIngestionTask);

}
