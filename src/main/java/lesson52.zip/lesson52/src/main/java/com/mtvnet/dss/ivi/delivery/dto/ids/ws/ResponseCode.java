package com.mtvnet.dss.ivi.delivery.dto.ids.ws;

import lombok.Getter;

public enum ResponseCode {

    OK(200, "OK"),

    IDS_UNCLASSIFIED_ERROR(1000, "Unclassified error during request processing"),

    INVALID_FREEWHEEL_NETWORK(2001, "Provided FreeWheel network is invalid"),
    INVALID_FEED_ENVIRONMENT(2002, "Provided feed environment is invalid"),
    INVALID_ARC_STAGE(2003, "Provided Arc stage is invalid"),
    INVALID_FEED_CONFIGURATION(2004, "Invalid feed configuration"),
    NO_MATCHING_FEED_FOUND(2005, "No matching feed found"),

    THIRDPARTY_SYSTEM_UNCLASSIFIED_ERROR(3000, "Unclassified error while accessing third-party system"),
    THIRDPARTY_SYSTEM_BAD_REQUEST(3001, "Bad request to third-party system"),
    THIRDPARTY_SYSTEM_AUTHENTICATION_RELATED_ERROR(3002,
            "Authentication and/or authorization related error while accessing third-party system");

    @Getter
    private final int code;
    @Getter
    private final String message;

    ResponseCode(int code, String message) {
        this.code = code;
        this.message = message;
    }

}
