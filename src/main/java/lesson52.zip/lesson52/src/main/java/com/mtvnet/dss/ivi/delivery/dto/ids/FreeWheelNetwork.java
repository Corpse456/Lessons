package com.mtvnet.dss.ivi.delivery.dto.ids;

import com.mtvnet.dss.ivi.delivery.dto.ids.ws.ResponseCode;
import com.mtvnet.dss.ivi.delivery.exception.IviDeliveryServiceException;

public enum FreeWheelNetwork {

    NETWORK_TEST("freewheel-test-network"), NETWORK_LIVE("freewheel-live-network"), NETWORK_INTL(
            "freewheel-intl-network");

    /**
     * name of the network used at configuration properties, which is mapped to this Enum
     */
    private final String configurationProperty;

    FreeWheelNetwork(String configurationProperty) {
        this.configurationProperty = configurationProperty;
    }

    /**
     * @return configuration property name, which is mapped to this Enum
     */
    public String getAsConfigurationProperty() {
        return configurationProperty;
    }

    /**
     * @return the Title value at Feed Configuration Arc response, which is mapped to this Enum
     */
    public String getAsArcTitleTagValue() {
        return configurationProperty;
    }

    /**
     * @return the value passed as Job Parameter, which is mapped to this Enum
     */
    public String getAsJobParameter() {
        return configurationProperty;
    }

    public static FreeWheelNetwork fromConfigProperty(String configProperty) {
        for (FreeWheelNetwork e : FreeWheelNetwork.values()) {
            if (e.configurationProperty.equals(configProperty)) {
                return e;
            }
        }
        throw new IviDeliveryServiceException("No FreeWheel network mapped to the name = " + configProperty,
                ResponseCode.INVALID_FREEWHEEL_NETWORK);
    }

    public static FreeWheelNetwork fromArcTitleTagValue(String arcTag) {
        return fromConfigProperty(arcTag);
    }

    public static FreeWheelNetwork fromJobParameter(String arcTag) {
        return fromConfigProperty(arcTag);
    }

}
