package com.mtvnet.dss.ivi.delivery.service.implementation;

import com.mtvnet.dss.ivi.delivery.dto.fep.FeedStatusElement;
import com.mtvnet.dss.ivi.delivery.dto.ids.FeedEnvironment;
import com.mtvnet.dss.ivi.delivery.dto.ids.ws.ResponseCode;
import com.mtvnet.dss.ivi.delivery.exception.IviDeliveryServiceException;
import com.mtvnet.dss.ivi.delivery.service.IFepFeedsStatusService;
import com.mtvnet.dss.ivi.delivery.service.implementation.client.FepFeedsStatusClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
@Slf4j
public class FepFeedsStatusService implements IFepFeedsStatusService {

    @Autowired
    private FepFeedsStatusClient fepFeedsStatusClient;

    @Value("${ivi.service.fep.bviFeedCategory}")
    private String bviFeedCategory;

    @Override
    public List<FeedStatusElement> retrieveFreeWheelFeedStatusList(FeedEnvironment feedEnvironment) {
        return queryFeedStatusList(feedEnvironment).stream()
                .filter(this::isFeedSuccessfulAndFreewheel)
                .collect(Collectors.toList());
    }

    @Override
    public FeedStatusElement retrieveFreeWheelFeedStatus(FeedEnvironment feedEnvironment, String feedName,
                                                         String feedParam) {
        return retrieveFreeWheelFeedStatusList(feedEnvironment).stream()
                .filter(feedStatus -> requestedFeedStatus(feedStatus, feedName, feedParam))
                .findFirst()
                .orElseThrow(() -> new IviDeliveryServiceException("No matching feed found!",
                        ResponseCode.NO_MATCHING_FEED_FOUND));
    }

    private boolean requestedFeedStatus(FeedStatusElement feedStatus, String feedName, String feedParam) {
        return feedName.equals(feedStatus.getFeedSchedule().getFeedName()) &&
                feedParam.equals(feedStatus.getFeedSchedule().getParamShortId());
    }

    private List<FeedStatusElement> queryFeedStatusList(FeedEnvironment feedEnvironment) {
        return fepFeedsStatusClient.feedStatusListForFeedEnvironment(feedEnvironment);
    }

    private boolean isFeedSuccessfulAndFreewheel(FeedStatusElement status) {
        return status != null && isStatusOk(status) && status.getFeedSchedule().getCategory().equals(bviFeedCategory);
    }

    private boolean isStatusOk(FeedStatusElement statusElement) {
        return "OK".equals(statusElement.getStatus());
    }

}
