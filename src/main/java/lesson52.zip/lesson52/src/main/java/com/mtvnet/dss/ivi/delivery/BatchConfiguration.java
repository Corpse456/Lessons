package com.mtvnet.dss.ivi.delivery;

import com.mtvnet.dss.ivi.delivery.batch.implementation.BviItemReader;
import com.mtvnet.dss.ivi.delivery.batch.implementation.BviItemTransformer;
import com.mtvnet.dss.ivi.delivery.batch.implementation.BviIviItemProcessor;
import com.mtvnet.dss.ivi.delivery.batch.implementation.FeedDownloadTasklet;
import com.mtvnet.dss.ivi.delivery.batch.implementation.IviItemWriter;
import com.mtvnet.dss.ivi.delivery.batch.implementation.IviJobExecutionListener;
import com.mtvnet.dss.ivi.delivery.dto.fep.BviVideoDocument;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.item.support.CompositeItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.batch.BatchDatabaseInitializer;
import org.springframework.boot.autoconfigure.batch.BatchProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ResourceLoader;

import javax.sql.DataSource;
import java.util.Arrays;

import static com.mtvnet.dss.ivi.delivery.batch.BatchConfigurationConstants.IVI_DELIVERY_JOB_BEAN_NAME;
import static com.mtvnet.dss.ivi.delivery.batch.BatchConfigurationConstants.IVI_DELIVERY_JOB_NAME;

@Configuration
@EnableBatchProcessing
@EnableConfigurationProperties(BatchProperties.class)
public class BatchConfiguration {

    @Autowired
    private BatchProperties properties;

    @Autowired
    private JobBuilderFactory jobBuilderFactory;

    @Autowired
    private StepBuilderFactory stepBuilderFactory;

    @Value("${ivi.service.job.chunkSize}")
    private int chunkSize;

    @Bean
    public BatchDatabaseInitializer batchDatabaseInitializer(DataSource dataSource, ResourceLoader resourceLoader) {
        return new BatchDatabaseInitializer(dataSource, resourceLoader, this.properties);
    }

    @Bean(name = IVI_DELIVERY_JOB_BEAN_NAME)
    public Job regularBviToIviTransformAndSendJob(@Autowired Step fepDownloadStep,
                                                  @Autowired Step bviItemProcessingStep,
                                                  @Autowired IviJobExecutionListener execListener) {
        Job job = jobBuilderFactory.get(IVI_DELIVERY_JOB_NAME).listener(execListener)
                .start(fepDownloadStep).next(bviItemProcessingStep).build();
        return job;
    }

    @Bean
    @JobScope
    public Step fepDownloadStep(@Autowired FeedDownloadTasklet tasklet) {
        return stepBuilderFactory.get("fepDownloadStep").tasklet(tasklet).allowStartIfComplete(true).build();
    }

    @Bean
    @JobScope
    public CompositeItemProcessor<BviVideoDocument, BviVideoDocument> transformAndProcessProcessor(
            @Autowired BviItemTransformer transformer,
            @Autowired BviIviItemProcessor processor) {
        CompositeItemProcessor<BviVideoDocument, BviVideoDocument> compositeItemProcessor =
                new CompositeItemProcessor<>();
        compositeItemProcessor.setDelegates(Arrays.asList(transformer, processor));
        return compositeItemProcessor;
    }

    @Bean
    @JobScope
    public Step bviItemProcessingStep(
            @Autowired BviItemReader reader,
            @Autowired CompositeItemProcessor<BviVideoDocument, BviVideoDocument> transformAndProcessProcessor,
            @Autowired IviItemWriter writer) {
        return stepBuilderFactory.get("bviItemProcessingStep").<BviVideoDocument, BviVideoDocument>chunk(chunkSize)
                .reader(reader).processor(transformAndProcessProcessor).writer(writer).build();
    }

}
