package com.mtvnet.dss.ivi.delivery.batch.implementation;

import com.mtvnet.dss.ivi.delivery.dto.fep.BviVideoDocument;
import com.mtvnet.dss.ivi.delivery.service.IBviVideoDocumentStatusStorageService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@JobScope
@Slf4j
public class BviIviItemProcessor implements ItemProcessor<BviVideoDocument, BviVideoDocument> {

    @Autowired
    private IBviVideoDocumentStatusStorageService videoDocumentStatusStorageService;

    @Override
    public BviVideoDocument process(BviVideoDocument videoDocument) throws Exception {
        log.debug("Processing item with id = " + videoDocument.getId());
        boolean awaitsUpdate = videoDocumentStatusStorageService.awaitsUpdate(videoDocument);
        log.debug("Item with id = {}, awaits update = {}", videoDocument.getId(), awaitsUpdate);
        return awaitsUpdate ? videoDocument : null;
    }

}
