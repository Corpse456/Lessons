package com.mtvnet.dss.ivi.delivery.dto.ids;

import lombok.Data;

import java.util.List;

@Data
public class ArcFeedConfiguration {

    private final List<FreeWheelNetwork> freeWheelNetworks;
    private final String site;

}
