package com.mtvnet.dss.ivi.delivery.dto.fep;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class FeedStatusElement {

    private String status;
    private String feedGenTimestamp;
    private FeedSchedule feedSchedule;

}
