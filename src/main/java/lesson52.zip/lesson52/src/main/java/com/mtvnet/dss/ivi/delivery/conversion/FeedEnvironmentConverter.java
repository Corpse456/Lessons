package com.mtvnet.dss.ivi.delivery.conversion;

import com.mtvnet.dss.ivi.delivery.dto.ids.FeedEnvironment;
import org.springframework.core.convert.converter.Converter;

public class FeedEnvironmentConverter implements Converter<String, FeedEnvironment> {

    @Override
    public FeedEnvironment convert(String feedEnvironmentName) {
        return FeedEnvironment.fromName(feedEnvironmentName);
    }

}
