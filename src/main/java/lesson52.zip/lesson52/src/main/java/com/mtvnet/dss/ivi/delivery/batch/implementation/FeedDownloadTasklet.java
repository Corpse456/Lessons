package com.mtvnet.dss.ivi.delivery.batch.implementation;

import com.mtvnet.dss.ivi.delivery.dto.ids.FeedEnvironment;
import com.mtvnet.dss.ivi.delivery.service.implementation.client.FepEnvironmentSpecificUrlBuilder;
import com.mtvnet.dss.ivi.delivery.utils.IviJobHttpUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.File;
import java.net.URL;

import static com.mtvnet.dss.ivi.delivery.batch.BatchConfigurationConstants.JOB_CONTEXT_TEMP_BVI_FILE_KEY;
import static com.mtvnet.dss.ivi.delivery.batch.BatchConfigurationConstants.JOB_CONTEXT_TEMP_DIR_KEY;
import static com.mtvnet.dss.ivi.delivery.utils.IviFileUtils.createTempXmlFileBasedOnJobParams;
import static com.mtvnet.dss.ivi.delivery.utils.IviJobUtils.fromJobContextViaChunkCotext;
import static com.mtvnet.dss.ivi.delivery.utils.IviJobUtils.updateJobContextViaChunkCotext;

@Component
@StepScope
@Slf4j
public class FeedDownloadTasklet implements Tasklet {

    @Autowired
    private FepEnvironmentSpecificUrlBuilder environmentSpecificUrlBuilder;

    @Value("${ivi.service.fep.downloadFeed.url.path}/#{jobParameters['feedName']}/#{jobParameters['feedParamShortId']}")
    private String downloadPath;

    @Value("#{jobParameters['feedEnvironment']}")
    private FeedEnvironment feedEnvironment;

    @Value("#{jobParameters['feedName']}")
    private String feedName;

    @Value("#{jobParameters['feedParamShortId']}")
    private String feedParamShortId;

    @Value("#{jobParameters['feedGenTimestamp']}")
    private String feedGenTimestamp;

    @Value("${ivi.service.fep.dateTimeFormat}")
    private String fepDateTimeFormatPattern;

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
        log.debug("Feed Download step started");
        File tempDirectory = (File) fromJobContextViaChunkCotext(chunkContext, JOB_CONTEXT_TEMP_DIR_KEY);
        File tempXmlFile = createTempXmlFileBasedOnJobParams(tempDirectory, feedEnvironment, feedGenTimestamp,
                fepDateTimeFormatPattern, feedName, feedParamShortId);
        IviJobHttpUtils.downloadBviFeed(tempXmlFile, feedDownloadUrl());
        updateJobContextViaChunkCotext(chunkContext, JOB_CONTEXT_TEMP_BVI_FILE_KEY, tempXmlFile);
        return RepeatStatus.FINISHED;
    }

    private URL feedDownloadUrl() {
        return environmentSpecificUrlBuilder.environmentSpecificFepUrl(feedEnvironment, downloadPath);
    }

}
