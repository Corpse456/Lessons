package com.mtvnet.dss.ivi.delivery;

import com.mtvnet.dss.ivi.delivery.dto.ids.FreeWheelNetwork;
import com.mtvnet.dss.ivi.delivery.batch.scheduler.FeedsDeliveryQueue;
import com.mtvnet.dss.ivi.delivery.service.IJobParametersFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.security.oauth2.client.resource.OAuth2ProtectedResourceDetails;
import org.springframework.security.oauth2.client.token.AccessTokenProviderChain;
import org.springframework.security.oauth2.client.token.grant.password.ResourceOwnerPasswordAccessTokenProvider;
import org.springframework.security.oauth2.client.token.grant.password.ResourceOwnerPasswordResourceDetails;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableOAuth2Client;
import org.springframework.util.Assert;

import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

@Configuration
@EnableOAuth2Client
@PropertySource("classpath:credentials-${spring.profiles.active}.properties")
public class FreeWheelOAuthConfiguration {

    @Bean
    public Map<FreeWheelNetwork, OAuth2ProtectedResourceDetails> freeWheelProtectedResourceDetails(
            @Value("${freewheel.endpoint.token}") String freeWheelTokenEndpoint,
            @Value("#{${freewheel.credentials.networks}}") Map<String, Map<String, String>> networkCredentials) {

        Map<FreeWheelNetwork, OAuth2ProtectedResourceDetails> detailsMap = new HashMap<>();
        networkCredentials.forEach((networkKey, singleUserPasswordMap) -> {
            Assert.isTrue(singleUserPasswordMap.size() == 1, "Exactly one user expected per every freewheel network");
            ResourceOwnerPasswordResourceDetails details = new ResourceOwnerPasswordResourceDetails();
            details.setUsername(singleUserPasswordMap.keySet().iterator().next());
            details.setPassword(singleUserPasswordMap.values().iterator().next());
            details.setAccessTokenUri(freeWheelTokenEndpoint);
            detailsMap.put(FreeWheelNetwork.fromConfigProperty(networkKey), details);
        });
        return detailsMap;
    }

    /**
     * Freewheel network key mapped to appropriate RestTemplate, which use different credentials.
     * But they all use single OAuth provider
     */
    @Bean
    public Map<FreeWheelNetwork, OAuth2RestTemplate> freeWheelRestTemplates(
            Map<FreeWheelNetwork, OAuth2ProtectedResourceDetails> detailsMap) {
        AccessTokenProviderChain provider = new AccessTokenProviderChain(
                Collections.singletonList(new ResourceOwnerPasswordAccessTokenProvider()));

        Map<FreeWheelNetwork, OAuth2RestTemplate> freeWheelRestTemplates = new HashMap<>();
        detailsMap.forEach((network, detail) -> {
            OAuth2RestTemplate template = new OAuth2RestTemplate(detail);
            template.setAccessTokenProvider(provider);
            template.getMessageConverters().add(0, new StringHttpMessageConverter(Charset.forName("UTF-8")));
            freeWheelRestTemplates.put(network, template);
        });
        return freeWheelRestTemplates;
    }

    /**
     * Freewheel network key mapped to appropriate execution queue
     */
    @Bean
    public Map<FreeWheelNetwork, FeedsDeliveryQueue> networkQueues(
            @Autowired IJobParametersFactory jobParametersFactory,
            @Autowired JobLauncher jobLauncher,
            @Autowired Job iviJob,
            @Value("#{${freewheel.endpoint.api.networks}}") Map<String, String> networks) {
        validateNetworkProperties(networks);
        Map<FreeWheelNetwork, FeedsDeliveryQueue> networkQueues = new HashMap<>();
        networks.keySet().forEach((networkKey) -> {
            FreeWheelNetwork network = FreeWheelNetwork.fromConfigProperty(networkKey);
            networkQueues.put(network, new FeedsDeliveryQueue(jobParametersFactory, jobLauncher, iviJob));
        });
        return networkQueues;
    }

    /**
     * networks value should be correct {KEY:URL} mapping:
     *
     * @param networks
     * @throws RuntimeException, not allowing application to start up
     */
    private static void validateNetworkProperties(Map<String, String> networks) {
        for (FreeWheelNetwork network : FreeWheelNetwork.values()) {
            String networkName = network.getAsConfigurationProperty();
            try {
                new URL(networks.get(networkName));
            } catch (MalformedURLException e) {
                throw new RuntimeException("Correct URL should be specified on startup for the freewheel network "
                        + networkName + ". But URL provided: " + networks.get(networkName));
            }
        }
    }

}
