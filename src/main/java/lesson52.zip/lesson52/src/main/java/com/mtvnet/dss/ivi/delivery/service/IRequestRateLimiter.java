package com.mtvnet.dss.ivi.delivery.service;

import com.mtvnet.dss.ivi.delivery.dto.ids.FreeWheelNetwork;

/**
 * Request rate limiter enforcing predefined rate limitations on a per-network basis.
 */
public interface IRequestRateLimiter {

    /**
     * Blocks calling thread till the moment when request execution will not violate predefined rate limitation for
     * a given {@code network}.
     *
     * @param freeWheelNetwork target ingestion network.
     */
    void ensureRequestRateLimit(FreeWheelNetwork freeWheelNetwork);

}
