package com.mtvnet.dss.ivi.delivery.batch;

import org.springframework.batch.core.BatchStatus;

import java.util.EnumSet;
import java.util.Set;

public final class BatchConfigurationConstants {

    public static final String IVI_DELIVERY_JOB_NAME = "regularBVItoIVITranformAndSendJob";
    public static final String IVI_DELIVERY_JOB_BEAN_NAME = "regularBVItoIVITranformAndSendJobBean";

    public static final String JOB_PARAMETER_FREEWHEEL_NETWORK = "freeWheelNetwork";
    public static final String JOB_PARAMETER_FEED_ENVIRONMENT = "feedEnvironment";
    public static final String JOB_PARAMETER_CATEGORY_NAME = "categoryName";
    public static final String JOB_PARAMETER_SITE_NAME = "siteName";
    public static final String JOB_PARAMETER_FEED_NAME = "feedName";
    public static final String JOB_PARAMETER_FEED_PARAM_SHORT_ID = "feedParamShortId";
    public static final String JOB_PARAMETER_FEED_GEN_TIMESTAMP = "feedGenTimestamp";

    /**
     * object type for this key in JobExecutionContext is java.io.File
     */
    public static final String JOB_CONTEXT_TEMP_DIR_KEY = "tempDir";

    /**
     * object type for this key in JobExecutionContext is java.io.File
     */
    public static final String JOB_CONTEXT_TEMP_BVI_FILE_KEY = "tempFile";

    /**
     * Standard Spring Batch statuses which are considered non failed:
     */
    public static final Set<BatchStatus> NON_FAIL_EXECUTION_STATUSES =
            EnumSet.of(BatchStatus.COMPLETED, BatchStatus.STARTING, BatchStatus.STARTED, BatchStatus.STOPPING);

    /**
     * Standard Spring Batch statuses which are considered as failed:
     */
    public static final Set<BatchStatus> FAIL_EXECUTION_STATUSES =
            EnumSet.of(BatchStatus.FAILED, BatchStatus.ABANDONED, BatchStatus.STOPPED);

    public static final String IVI_XML_ITEM_NAME = "FWVideoDocument";
    public static final String IVI_XML_DOC_ID_ATTR_NAME = "video_id";

}
