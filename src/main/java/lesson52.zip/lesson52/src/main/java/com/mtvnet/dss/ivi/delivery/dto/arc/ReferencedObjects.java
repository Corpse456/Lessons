package com.mtvnet.dss.ivi.delivery.dto.arc;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ReferencedObjects {

    @JsonProperty("Sites")
    private List<ReferencedObject> sites;
    @Valid
    @NotNull
    @JsonProperty("Tags")
    private List<ReferencedObject> tags;

}
