package com.mtvnet.dss.ivi.delivery.dto.fep;

/**
 * Enumeration containing possible content statuses for a given video document.
 */
public enum ContentStatus {

    /**
     * Given video document is up to date, meaning that last delivery attempt of a video document with a given hash has
     * completed successfully.
     */
    UP_TO_DATE,

    /**
     * Given video document is outdated.
     */
    OUTDATED,

    /**
     * Can't determine if content is up to date or not, as no delivery history is available for a given video
     * document.
     */
    UNKNOWN;

    /**
     * Checks if this enum constant indicates that certain content item awaits update.
     *
     * @return true, if this enum constant indicates that certain content item awaits update
     */
    public boolean awaitsUpdate() {
        return this != UP_TO_DATE;
    }

}
