package com.mtvnet.dss.ivi.delivery.batch.implementation;

import com.mtvnet.dss.ivi.delivery.dto.fep.BviVideoDocument;
import com.mtvnet.dss.ivi.delivery.service.IContentHashingService;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@JobScope
public class BviItemTransformer implements ItemProcessor<BviVideoDocument, BviVideoDocument> {

    @Value("#{jobParameters['categoryName']}")
    private String categoryName;

    @Value("#{jobParameters['siteName']}")
    private String siteName;

    @Value("#{jobParameters['feedName']}")
    private String feedName;

    @Value("#{jobParameters['freeWheelNetwork']}")
    private String freeWheelNetwork;

    @Autowired
    private IContentHashingService contentHashingService;

    @Override
    public BviVideoDocument process(BviVideoDocument videoDocument) throws Exception {
        String contentHash = contentHashingService.calculateContentHash(videoDocument);
        videoDocument.setDocumentScope(String.join(":", categoryName, siteName, feedName, freeWheelNetwork));
        videoDocument.setDocumentHash(contentHash);
        return videoDocument;
    }

}
