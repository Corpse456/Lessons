package com.mtvnet.dss.ivi.delivery.service;

import com.mtvnet.dss.ivi.delivery.dto.ids.ArcFeedConfiguration;
import com.mtvnet.dss.ivi.delivery.dto.ids.FeedEnvironment;

public interface IArcFeedConfigurationService {

    ArcFeedConfiguration retrieveArcIngestionConfiguration(FeedEnvironment feedEnvironment, String feedName);

}
