package com.mtvnet.dss.ivi.delivery.batch.implementation;

import com.mtvnet.dss.ivi.delivery.dto.ids.FeedEnvironment;
import com.mtvnet.dss.ivi.delivery.utils.IviFileUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.File;

import static com.mtvnet.dss.ivi.delivery.batch.BatchConfigurationConstants.JOB_CONTEXT_TEMP_DIR_KEY;

@Slf4j
@Component
@JobScope
public class IviJobExecutionListener implements JobExecutionListener {

    private static final long MILLI_MULTIPLIER = 1000L;

    @Value("${ivi.service.tempDirectory}")
    private String appTempDirectory;

    @Value("#{jobParameters['feedEnvironment']}")
    private FeedEnvironment feedEnvironment;

    @Value("#{jobParameters['feedName']}")
    private String feedName;

    @Value("#{jobParameters['feedParamShortId']}")
    private String feedParamShortId;

    @Value("#{jobParameters['feedGenTimestamp']}")
    private String feedGenTimestamp;

    @Value("#{jobParameters['freeWheelNetwork']}")
    private String freewheelNetwork;

    @Value("${ivi.service.fep.dateTimeFormat}")
    private String fepDateTimeFormatPattern;

    @Override
    public void beforeJob(JobExecution jobExecution) {
        log.info("Ivi job has started with job parameters = " + jobExecution.getJobParameters());
        File jobTempDir = IviFileUtils.recreateJobTempDirectory(appTempDirectory, feedEnvironment, feedGenTimestamp,
                fepDateTimeFormatPattern, feedName, feedParamShortId, freewheelNetwork);
        log.debug("Job temp directory recreated: " + jobTempDir.getAbsolutePath());
        jobExecution.getExecutionContext().put(JOB_CONTEXT_TEMP_DIR_KEY, jobTempDir);
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        cleanUp(jobExecution);
        log.info("Ivi delivery job has finished with job parameters = {} and with result = {}",
                jobExecution.getJobParameters(), jobExecution.getStatus());
        long durationInMillis = jobExecution.getStartTime().getTime() - jobExecution.getEndTime().getTime();
        log.debug("Job execution time: {}", durationInMillis / (float) MILLI_MULTIPLIER);
    }

    private void cleanUp(JobExecution jobExecution) {
        File tempDir = (File) jobExecution.getExecutionContext().get(JOB_CONTEXT_TEMP_DIR_KEY);
        IviFileUtils.deleteDirSafelyAndLog(tempDir);
    }

}
