package com.mtvnet.dss.ivi.delivery.dto.arc;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class FeedConfiguration {

    @JsonProperty("Category")
    private ReferencedObject category;
    @JsonProperty("FeedName")
    private String feedName;
    @Valid
    @NotNull
    @JsonProperty("ReferencedObjects")
    private ReferencedObjects referencedObjects;

}
