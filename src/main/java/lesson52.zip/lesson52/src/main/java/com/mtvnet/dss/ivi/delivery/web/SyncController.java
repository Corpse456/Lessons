package com.mtvnet.dss.ivi.delivery.web;

import com.mtvnet.dss.ivi.delivery.dto.ids.FreeWheelNetwork;
import com.mtvnet.dss.ivi.delivery.dto.ids.ws.Response;
import com.mtvnet.dss.ivi.delivery.dto.ids.ws.ResponseCode;
import com.mtvnet.dss.ivi.delivery.dto.ids.ws.ResponseSource;
import com.mtvnet.dss.ivi.delivery.exception.ThirdPartySystemAccessException;
import com.mtvnet.dss.ivi.delivery.service.IFreeWheelDeliveryService;
import com.mtvnet.dss.ivi.delivery.web.implementation.SyncErrorResponseProducer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@RestController
@Slf4j
public class SyncController {

    private static final Pattern VIDEO_ID_PATTERN = Pattern.compile("video_id=\"([^\"]*)\"");

    @Autowired
    private IFreeWheelDeliveryService freeWheelDeliveryService;

    @Autowired
    private SyncErrorResponseProducer syncErrorResponseProducer;

    @RequestMapping(path = "/ingest/sync", method = RequestMethod.POST, consumes = MediaType.APPLICATION_XML_VALUE,
            produces = MediaType.APPLICATION_XML_VALUE)
    public ResponseEntity<Response> ingest(@RequestParam(value = "network") String network,
                                           @RequestBody String iviItem) {
        log.info("/ingest/sync called for network = {}, id = {}", network, videoDocumentId(iviItem));
        return validFreeWheelNetwork(network) ?
                proceed(FreeWheelNetwork.fromArcTitleTagValue(network), iviItem) : badRequest();
    }

    @ExceptionHandler(ThirdPartySystemAccessException.class)
    public ResponseEntity<Response> handleFreeWheelDeliveryException(ThirdPartySystemAccessException e) {
        return syncErrorResponseProducer.produceErrorResponse(e);
    }

    private boolean validFreeWheelNetwork(String network) {
        return Arrays.stream(FreeWheelNetwork.values())
                .map(FreeWheelNetwork::getAsArcTitleTagValue).anyMatch(network::equals);
    }

    private ResponseEntity<Response> proceed(FreeWheelNetwork network, String iviItem) {
        freeWheelDeliveryService.ingestIviDocuments(iviItem, network);
        log.info("/ingest/sync call completed successfully");
        return ResponseEntity.ok().build();
    }

    private ResponseEntity<Response> badRequest() {
        log.info("/ingest/sync call failed to pass network name validation");
        return ResponseEntity.badRequest().body(
                Response.with(ResponseSource.IDS, ResponseCode.INVALID_FREEWHEEL_NETWORK, null));
    }

    private String videoDocumentId(String iviItem) {
        Matcher matcher = VIDEO_ID_PATTERN.matcher(iviItem);
        return matcher.find() ? matcher.group(1) : null;
    }

}
