package com.mtvnet.dss.ivi.delivery.batch.implementation;

import com.mtvnet.dss.ivi.delivery.dto.fep.BviVideoDocument;
import com.mtvnet.dss.ivi.delivery.dto.fep.DeliveryStatus;
import com.mtvnet.dss.ivi.delivery.dto.ids.FreeWheelNetwork;
import com.mtvnet.dss.ivi.delivery.service.IBviVideoDocumentStatusStorageService;
import com.mtvnet.dss.ivi.delivery.service.IFreeWheelDeliveryService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@JobScope
@Slf4j
public class IviItemWriter implements ItemWriter<BviVideoDocument> {

    private int chunkNumber = 0;

    @Autowired
    private IFreeWheelDeliveryService deliveryService;

    @Autowired
    private IBviVideoDocumentStatusStorageService videoDocumentStatusStorageService;

    @Value("#{jobParameters['freeWheelNetwork']}")
    private FreeWheelNetwork freeWheelNetwork;

    @Override
    public void write(List<? extends BviVideoDocument> videoDocuments) throws Exception {
        log.debug("writing item list #" + (++chunkNumber) + ", list size is" + videoDocuments.size());
        if (videoDocuments.size() != 0) {
            deliveryService.ingestIviDocuments(videoDocuments, freeWheelNetwork);
            videoDocumentStatusStorageService.storeVideoDocumentStatus(videoDocuments, DeliveryStatus.DELIVERED);
        } else {
            log.debug("Nothing to deliver, empty chunk received.");
        }
    }

}
