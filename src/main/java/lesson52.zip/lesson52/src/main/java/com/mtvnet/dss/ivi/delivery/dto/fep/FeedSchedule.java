package com.mtvnet.dss.ivi.delivery.dto.fep;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class FeedSchedule {

    private String feedName;
    private String feedShortId;
    private String paramName;
    private String paramShortId;
    private String category;
    private Map<String, String> parameters;

}
