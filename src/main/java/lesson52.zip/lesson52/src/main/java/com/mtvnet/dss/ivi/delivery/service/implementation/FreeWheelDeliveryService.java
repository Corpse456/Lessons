package com.mtvnet.dss.ivi.delivery.service.implementation;

import com.mtvnet.dss.ivi.delivery.dto.ids.FreeWheelNetwork;
import com.mtvnet.dss.ivi.delivery.dto.fep.BviVideoDocument;
import com.mtvnet.dss.ivi.delivery.dto.ids.ws.ResponseCode;
import com.mtvnet.dss.ivi.delivery.exception.ThirdPartySystemAccessException;
import com.mtvnet.dss.ivi.delivery.service.IFreeWheelDeliveryService;
import com.mtvnet.dss.ivi.delivery.utils.IviJobUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.security.oauth2.common.exceptions.OAuth2Exception;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

@Component
@Slf4j
public class FreeWheelDeliveryService implements IFreeWheelDeliveryService {

    @Autowired
    private Map<FreeWheelNetwork, OAuth2RestTemplate> freeWheelRestTemplates;

    @Autowired
    private RequestRateLimiter requestRateLimiter;

    @Value("#{${freewheel.endpoint.api.networks}}")
    private Map<FreeWheelNetwork, String> networks;

    @Override
    public void ingestIviDocuments(List<? extends BviVideoDocument> items, FreeWheelNetwork freeWheelNetwork) {
        String xmlBody = IviJobUtils.wrapBviDocumentsToHttpPostBody(items);
        doIngest(xmlBody, freeWheelNetwork);
    }

    @Override
    public void ingestIviDocuments(String iviItems, FreeWheelNetwork freeWheelNetwork) {
        try {
            doIngest(iviItems, freeWheelNetwork);
        } catch (OAuth2Exception e) {
            throw new ThirdPartySystemAccessException(e, ResponseCode.THIRDPARTY_SYSTEM_AUTHENTICATION_RELATED_ERROR);
        } catch (RuntimeException e) {
            throw new ThirdPartySystemAccessException(e, ResponseCode.THIRDPARTY_SYSTEM_UNCLASSIFIED_ERROR);
        }
    }

    private void doIngest(String xmlBody, FreeWheelNetwork freeWheelNetwork) {
        String freeWheelApiEndpoint = networks.get(freeWheelNetwork);
        RestTemplate freeWheelRestTemplate = freeWheelRestTemplates.get(freeWheelNetwork);
        log.debug("Sending IVI data to Freewheel: " + freeWheelApiEndpoint);

        requestRateLimiter.ensureRequestRateLimit(freeWheelNetwork);
        tryHttpPostRequest(xmlBody, freeWheelApiEndpoint, freeWheelRestTemplate);
    }

    private void tryHttpPostRequest(String xmlBody, String freeWheelApiEndpoint, RestTemplate freeWheelRestTemplate) {
        ResponseEntity<String> response;
        try {
            response = freeWheelRestTemplate.postForEntity(freeWheelApiEndpoint, xmlBody, String.class);
            logDebug(response);
        } catch (HttpClientErrorException e) {
            logHttpError(e);
            throw e;
        } catch (Exception e) {
            log.error("Unexpected error while connecting to Freewheel: ", e);
            throw e;
        }
    }

    private void logDebug(ResponseEntity<?> response) {
        if (log.isDebugEnabled()) {
            if (response == null) {
                log.debug("response=null");
                return;
            }
            log.debug("Response status: " + response.getStatusCodeValue() + " "
                    + response.getStatusCode().getReasonPhrase());
            log.debug("Response body: " + response.getBody());
        }
    }

    private void logHttpError(HttpClientErrorException e) {
        log.error("IVI injection to Freewheel failed.");
        log.error("Freewheel Response status is: " + e.getStatusText());
        log.error("Response body is: " + e.getResponseBodyAsString());
    }

}
