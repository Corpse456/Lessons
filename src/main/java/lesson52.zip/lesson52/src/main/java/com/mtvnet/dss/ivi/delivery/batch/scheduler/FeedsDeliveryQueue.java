package com.mtvnet.dss.ivi.delivery.batch.scheduler;

import com.mtvnet.dss.ivi.delivery.dto.ids.FeedIngestionTask;
import com.mtvnet.dss.ivi.delivery.service.IJobParametersFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.util.Assert;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

import static com.mtvnet.dss.ivi.delivery.utils.IviJobUtils.feedNameAndParam;

/**
 * The queue is responsible both for queuing and launching delivery jobs.
 * Delivery Job starts asynchronously on adding new feed, or when previous
 * execution is finished. The queue is thread safe.
 */
@Slf4j
public class FeedsDeliveryQueue {

    private IJobParametersFactory jobParametersFactory;
    private JobLauncher jobLauncher;
    private Job iviJob;

    private ExecutorService singleThreadExecutor = Executors.newSingleThreadExecutor();
    private Map<FeedIngestionTask, Future<ExitStatus>> deliveryResults = new HashMap<>();

    public FeedsDeliveryQueue(IJobParametersFactory jobParametersFactory, JobLauncher jobLauncher, Job iviJob) {
	this.jobParametersFactory = jobParametersFactory;
	this.jobLauncher = jobLauncher;
	this.iviJob = iviJob;
    }

    public void addFeed(FeedIngestionTask feedIngestionTask) {
	Assert.notNull(feedIngestionTask, "Delivery queue expects no null pointers as input");
	if (deliveryResults.keySet().contains(feedIngestionTask)) {
	    log.warn("Feed {} added to execution queue, but it is already in the waiting queue or just have been "
		    + "delivered", feedNameAndParam(feedIngestionTask));
	    return;
	}
	Future<ExitStatus> futureResult = singleThreadExecutor.submit(new IviJobExecutionTask(feedIngestionTask));
	deliveryResults.put(feedIngestionTask, futureResult);
	filterCompleteResults();
	debugLogQueueStatus(feedIngestionTask);
    }

    /**
     * excludes finished future results from deliveryResults Map
     */
    private void filterCompleteResults() {
	deliveryResults = deliveryResults.entrySet().stream().filter((entry) -> !entry.getValue().isDone())
		.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
    }

    private void debugLogQueueStatus(FeedIngestionTask addedTask) {
	log.debug("Last added new feed to execute: {}. Freewheel network: {}. Queue size is : {}",
		feedNameAndParam(addedTask), addedTask.getFreeWheelNetwork(), deliveryResults.size());
    }

    private class IviJobExecutionTask implements Callable<ExitStatus> {

	private final FeedIngestionTask feedIngestionTask;

	IviJobExecutionTask(FeedIngestionTask feedIngestionTask) {
	    this.feedIngestionTask = feedIngestionTask;
	}

	/**
	 * Runs new job execution in this thread. There is small probability of the
	 * restart attempt to be made, if feed returned by feedCheckService has been
	 * finished/cleaned in time between status check and this queue update. It is
	 * safe to ignore.
	 */
	@Override
	public ExitStatus call() throws Exception {
	    try {
		JobParameters parameters = jobParametersFactory.createJobParameters(feedIngestionTask);
		log.debug("Delivery job started asynchronously with parameters: {}", parameters.getParameters());
		JobExecution execution = jobLauncher.run(iviJob, parameters);
		return execution.getExitStatus();
	    } catch (JobInstanceAlreadyCompleteException e) {
		log.warn("Feed {} is already complete, but restart attempt is made.",
			feedNameAndParam(feedIngestionTask));
		return ExitStatus.COMPLETED;
	    } catch (Exception e) {
		log.error("Unexpected error while executing IviJob: ", e);
		throw e;
	    }
	}

    }

}
