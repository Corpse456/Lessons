package com.mtvnet.dss.ivi.delivery.web;

import com.mtvnet.dss.ivi.delivery.dto.ids.ws.Response;
import com.mtvnet.dss.ivi.delivery.dto.ids.ws.ResponseCode;
import com.mtvnet.dss.ivi.delivery.dto.ids.ws.ResponseSource;
import com.mtvnet.dss.ivi.delivery.web.implementation.ExceptionTrackingDelegate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.web.BasicErrorController;
import org.springframework.boot.autoconfigure.web.ErrorAttributes;
import org.springframework.boot.autoconfigure.web.ErrorProperties;
import org.springframework.boot.autoconfigure.web.ErrorViewResolver;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping({"${server.error.path:${error.path:/error}}"})
public class ErrorController implements org.springframework.boot.autoconfigure.web.ErrorController {

    @Autowired
    private ExceptionTrackingDelegate exceptionTrackingDelegate;

    private BasicErrorController basicErrorController;

    public ErrorController(ErrorAttributes errorAttributes, ErrorProperties errorProperties, List<ErrorViewResolver>
            errorViewResolvers) {
        basicErrorController = new BasicErrorController(errorAttributes, errorProperties, errorViewResolvers);
    }

    @RequestMapping(produces = {"text/html"})
    public ModelAndView errorHtml(HttpServletRequest request, HttpServletResponse response) {
        return basicErrorController.errorHtml(request, response);
    }

    @RequestMapping
    public ResponseEntity<Response> error(HttpServletRequest request) {
        ResponseEntity<Map<String, Object>> responseEntity = basicErrorController.error(request);
        HttpStatus statusCode = responseEntity.getStatusCode();
        Map<String, Object> errorAttributes = responseEntity.getBody();

        Throwable exception = valueFromMapWithCast(errorAttributes, "exception", Throwable.class);
        String payload = valueFromMapWithCast(errorAttributes, "message", String.class);

        return exceptionTrackingDelegate.reportAndGenerateEntityWithTraceReference(exception, statusCode,
                Response.with(ResponseSource.IDS, ResponseCode.IDS_UNCLASSIFIED_ERROR, payload));
    }

    @SuppressWarnings("unchecked")
    private <T> T valueFromMapWithCast(Map<String, Object> map, String key, Class<T> clazz) {
        Object object = map.get(key);
        return clazz.isInstance(object) ? (T) object : null;
    }

    @Override
    public String getErrorPath() {
        return basicErrorController.getErrorPath();
    }

}
