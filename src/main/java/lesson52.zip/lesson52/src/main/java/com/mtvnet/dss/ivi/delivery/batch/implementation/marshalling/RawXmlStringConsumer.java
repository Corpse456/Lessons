package com.mtvnet.dss.ivi.delivery.batch.implementation.marshalling;

import org.springframework.oxm.UnmarshallingFailureException;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.XMLEvent;
import java.io.StringWriter;
import java.util.function.Consumer;
import java.util.function.Supplier;

class RawXmlStringConsumer implements Consumer<XMLEvent>, Supplier<String> {

    private final StringWriter rawXmlStringWriter = new StringWriter();

    @Override
    public void accept(XMLEvent xmlEvent) {
        try {
            xmlEvent.writeAsEncodedUnicode(rawXmlStringWriter);
        } catch (XMLStreamException e) {
            throw new UnmarshallingFailureException(e.getMessage(), e);
        }
    }

    @Override
    public String get() {
        return rawXmlStringWriter.toString();
    }

}
