package com.mtvnet.dss.ivi.delivery.web.implementation;

import com.mtvnet.dss.ivi.delivery.dto.ids.ws.Response;
import com.mtvnet.dss.ivi.delivery.dto.ids.ws.ResponseCode;
import com.mtvnet.dss.ivi.delivery.dto.ids.ws.ResponseSource;
import com.mtvnet.dss.ivi.delivery.exception.ThirdPartySystemAccessException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;

@Component
public class SyncErrorResponseProducer {

    @Autowired
    private ExceptionTrackingDelegate exceptionTrackingDelegate;

    public ResponseEntity<Response> produceErrorResponse(ThirdPartySystemAccessException exception) {
        return causedByBadRequest(exception) ?
                badRequest(exception, badRequestResponsePayload(exception)) :
                internalServerError(exception);
    }

    private boolean causedByBadRequest(ThirdPartySystemAccessException exception) {
        return (exception.getCause() instanceof HttpStatusCodeException) &&
                (((HttpStatusCodeException) exception.getCause()).getStatusCode() == HttpStatus.BAD_REQUEST);
    }

    private String badRequestResponsePayload(ThirdPartySystemAccessException exception) {
        return ((HttpStatusCodeException) exception.getCause()).getResponseBodyAsString();
    }

    private ResponseEntity<Response> badRequest(ThirdPartySystemAccessException exception, String payload) {
        return exceptionTrackingDelegate.reportAndGenerateEntityWithTraceReference(exception, HttpStatus.BAD_REQUEST,
                Response.with(ResponseSource.FREEWHEEL, ResponseCode.THIRDPARTY_SYSTEM_BAD_REQUEST, payload));
    }

    private ResponseEntity<Response> internalServerError(ThirdPartySystemAccessException exception) {
        return exceptionTrackingDelegate.reportAndGenerateEntityWithTraceReference(exception,
                HttpStatus.INTERNAL_SERVER_ERROR,
                Response.with(ResponseSource.FREEWHEEL, exception.getResponseCode(), null));
    }

}
