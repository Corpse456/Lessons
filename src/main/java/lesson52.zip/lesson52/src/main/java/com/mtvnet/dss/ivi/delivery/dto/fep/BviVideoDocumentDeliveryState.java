package com.mtvnet.dss.ivi.delivery.dto.fep;

import lombok.Data;

import java.util.Date;

@Data
public class BviVideoDocumentDeliveryState {

    private final String documentHash;
    private final DeliveryStatus deliveryStatus;
    private final Date deliveredAt;

}
