package com.mtvnet.dss.ivi.delivery.exception;

import com.mtvnet.dss.ivi.delivery.dto.ids.ws.ResponseCode;

public class ThirdPartySystemAccessException extends IviDeliveryServiceException {

    private static final long serialVersionUID = -2316820402121298371L;

    public ThirdPartySystemAccessException(ResponseCode responseCode) {
        super(responseCode);
    }

    public ThirdPartySystemAccessException(String message, ResponseCode responseCode) {
        super(message, responseCode);
    }

    public ThirdPartySystemAccessException(String message, Throwable cause, ResponseCode responseCode) {
        super(message, cause, responseCode);
    }

    public ThirdPartySystemAccessException(Throwable cause, ResponseCode responseCode) {
        super(cause, responseCode);
    }

    public ThirdPartySystemAccessException(String message, Throwable cause, boolean enableSuppression, boolean
            writableStackTrace, ResponseCode responseCode) {
        super(message, cause, enableSuppression, writableStackTrace, responseCode);
    }

}
