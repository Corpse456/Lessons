package com.mtvnet.dss.ivi.delivery.service;

import java.util.Map;

/**
 * Key-value storage service.
 */
public interface IKeyValueStorageService<K, V> {

    V get(K key);

    V put(K key, V value);

    void putAll(Map<? extends K, ? extends V> m);

    V remove(K key);

}
