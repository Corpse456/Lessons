package com.mtvnet.dss.ivi.delivery.dto.fep;

import lombok.Data;

@Data
public class BviVideoDocument {

    private final String id;
    private final String rawXmlString;
    private final String hashXmlString;
    /**
     * A combination of a category name, site name, feed name, FreeWheel network joined using ":" as a field separator
     * for a given video document.
     */
    private String documentScope;
    private String documentHash;

}
