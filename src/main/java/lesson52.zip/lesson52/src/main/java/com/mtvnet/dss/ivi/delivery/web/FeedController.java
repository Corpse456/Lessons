package com.mtvnet.dss.ivi.delivery.web;


import com.mtvnet.dss.ivi.delivery.dto.ids.FeedEnvironment;
import com.mtvnet.dss.ivi.delivery.dto.ids.FeedIngestionTask;
import com.mtvnet.dss.ivi.delivery.dto.ids.FreeWheelNetwork;
import com.mtvnet.dss.ivi.delivery.dto.ids.ws.Response;
import com.mtvnet.dss.ivi.delivery.dto.ids.ws.ResponseCode;
import com.mtvnet.dss.ivi.delivery.dto.ids.ws.ResponseSource;
import com.mtvnet.dss.ivi.delivery.exception.IviDeliveryServiceException;
import com.mtvnet.dss.ivi.delivery.service.IIngestionTaskDispatcher;
import com.mtvnet.dss.ivi.delivery.service.IIngestionTasksSupplier;
import com.mtvnet.dss.ivi.delivery.web.implementation.ExceptionTrackingDelegate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;

@RestController
@Slf4j
public class FeedController {

    @Autowired
    private IIngestionTasksSupplier ingestionTasksSupplier;

    @Autowired
    private IIngestionTaskDispatcher ingestionTaskDispatcher;

    @Autowired
    private ExceptionTrackingDelegate exceptionTrackingDelegate;

    @RequestMapping(path = "/ingest/feed", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Response> ingest(@RequestParam(value = "network") String network,
                                           @RequestParam(value = "feed_environment") String feedEnvironment,
                                           @RequestParam(value = "feed_name") String feedName,
                                           @RequestParam(value = "feed_param") String feedParam) {
        log.info("/ingest/feed called for network = {}", network);
        ResponseEntity<Response> response;
        if (validFreeWheelNetwork(network)) {
            if (validFeedEnvironment(feedEnvironment)) {
                response = proceed(FreeWheelNetwork.fromArcTitleTagValue(network),
                        FeedEnvironment.fromName(feedEnvironment), feedName, feedParam);
            } else {
                response = badRequest(ResponseCode.INVALID_FEED_ENVIRONMENT);
            }
        } else {
            response = badRequest(ResponseCode.INVALID_FREEWHEEL_NETWORK);
        }
        return response;
    }

    @ExceptionHandler(IviDeliveryServiceException.class)
    public ResponseEntity<Response> handleIviDeliveryServiceException(IviDeliveryServiceException e) {
        return exceptionTrackingDelegate.reportAndGenerateEntityWithTraceReference(e, HttpStatus.INTERNAL_SERVER_ERROR,
                Response.with(ResponseSource.IDS, e.getResponseCode(), null));
    }

    private boolean validFreeWheelNetwork(String network) {
        return Arrays.stream(FreeWheelNetwork.values())
                .map(FreeWheelNetwork::getAsArcTitleTagValue).anyMatch(network::equals);
    }

    private boolean validFeedEnvironment(String feedEnvironment) {
        return Arrays.stream(FeedEnvironment.values())
                .map(FeedEnvironment::getName).anyMatch(feedEnvironment::equals);
    }

    private ResponseEntity<Response> proceed(FreeWheelNetwork network, FeedEnvironment feedEnvironment, String feedName,
                                             String feedParam) {
        FeedIngestionTask feedIngestionTask = ingestionTasksSupplier.requestIngestionTaskFor(feedEnvironment,
                network, feedName, feedParam);
        ingestionTaskDispatcher.dispatchIngestion(feedIngestionTask);
        log.info("/ingest/feed call completed successfully");
        return ResponseEntity.ok().build();
    }

    private ResponseEntity<Response> badRequest(ResponseCode responseCode) {
        log.info("/ingest/feed call failed to pass validation with code {}", responseCode);
        return ResponseEntity.badRequest().body(
                Response.with(ResponseSource.IDS, responseCode, null));
    }

}
