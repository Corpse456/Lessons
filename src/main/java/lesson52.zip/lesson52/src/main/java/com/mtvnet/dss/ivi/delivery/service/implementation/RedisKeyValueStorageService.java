package com.mtvnet.dss.ivi.delivery.service.implementation;

import com.mtvnet.dss.ivi.delivery.service.IKeyValueStorageService;
import org.springframework.context.annotation.Profile;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import java.util.Map;

/**
 * Implementation of {@link IKeyValueStorageService} storing values in Redis.
 */
@Component
@Profile("!local")
public class RedisKeyValueStorageService<K, V> implements IKeyValueStorageService<K, V> {

    private RedisTemplate<K, V> redisTemplate;
    private ValueOperations<K, V> valueOperations;

    public RedisKeyValueStorageService(RedisTemplate<K, V> redisTemplate) {
        Assert.notNull(redisTemplate, "redisTemplate should be not null!");
        this.redisTemplate = redisTemplate;
        this.valueOperations = redisTemplate.opsForValue();
    }

    @Override
    public V get(K key) {
        return valueOperations.get(key);
    }

    @Override
    public V put(K key, V value) {
        V preservedValue = get(key);
        valueOperations.set(key, value);
        return preservedValue;
    }

    @Override
    public void putAll(Map<? extends K, ? extends V> m) {
        valueOperations.multiSet(m);
    }

    @Override
    public V remove(K key) {
        V preservedValue = get(key);
        redisTemplate.delete(key);
        return preservedValue;
    }

}
