package com.mtvnet.dss.ivi.delivery.dto.fep;

/**
 * Enumeration containing possible delivery statuses for a given video document.
 */
public enum DeliveryStatus {

    /**
     * Delivery of a given video document has completed successfully.
     */
    DELIVERED,

    /**
     * Delivery of a given video document has failed.
     */
    FAILED,

    /**
     * Can't determine if delivery has failed or succeeded, as no delivery history is available for a given video
     * document.
     */
    UNKNOWN;

    /**
     * Checks if this enum constant indicates that certain content item awaits delivery (no matter of the reason: it
     * is either has never delivered or last delivery attempt has failed).
     *
     * @return true, if this enum constant indicates that certain content item awaits delivery.
     */
    public boolean awaitsDelivery() {
        return this != DELIVERED;
    }

}
