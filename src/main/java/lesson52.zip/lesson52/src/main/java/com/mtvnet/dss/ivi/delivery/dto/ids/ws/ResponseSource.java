package com.mtvnet.dss.ivi.delivery.dto.ids.ws;

public enum ResponseSource {

    IDS,
    FREEWHEEL

}
