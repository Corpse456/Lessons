package com.mtvnet.dss.ivi.delivery.service;

import com.mtvnet.dss.ivi.delivery.dto.fep.BviVideoDocument;

/**
 * Content hashing service responsible for calculating hashes using during content status checks to determine if a
 * given video document has updated or not.
 */
public interface IContentHashingService {

    /**
     * Calculates content hash based on provided message payload.
     *
     * @param videoDocument video document to calculate hash for.
     * @return content hash.
     */
    String calculateContentHash(BviVideoDocument videoDocument);

}
