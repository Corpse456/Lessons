package com.mtvnet.dss.ivi.delivery.web.implementation;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
@Slf4j
public class ExceptionTrackingDelegate {

    public <T> ResponseEntity<T> reportAndGenerateEntityWithTraceReference(Throwable e, HttpStatus statusCode,
                                                                           T body) {
        String traceReference = makeTraceReference();
        log.error("Encountered exception while executing REST API call, trace reference {}:", traceReference, e);
        return new ResponseEntity<T>(body, makeTraceReferenceHeader(traceReference), statusCode);
    }

    private HttpHeaders makeTraceReferenceHeader(String traceReference) {
        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Trace-Reference", traceReference);
        return headers;
    }

    private String makeTraceReference() {
        return UUID.randomUUID().toString().replace("-", "");
    }

}
