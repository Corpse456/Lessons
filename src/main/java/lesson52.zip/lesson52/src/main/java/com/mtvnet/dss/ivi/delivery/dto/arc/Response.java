package com.mtvnet.dss.ivi.delivery.dto.arc;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Response {

    @Valid
    @NotNull
    @Size(min = 1, max = 1)
    private List<FeedConfiguration> docs;

}
