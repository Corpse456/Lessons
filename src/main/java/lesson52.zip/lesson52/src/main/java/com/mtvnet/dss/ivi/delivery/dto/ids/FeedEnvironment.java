package com.mtvnet.dss.ivi.delivery.dto.ids;

import com.mtvnet.dss.ivi.delivery.dto.ids.ws.ResponseCode;
import com.mtvnet.dss.ivi.delivery.exception.IviDeliveryServiceException;
import lombok.Getter;

public enum FeedEnvironment {

    QA("qa"), LIVE("live");

    @Getter
    private final String name;

    FeedEnvironment(String name) {
        this.name = name;
    }

    public static FeedEnvironment fromName(String name) {
        for (FeedEnvironment environment : FeedEnvironment.values()) {
            if (environment.name.equals(name)) {
                return environment;
            }
        }
        throw new IviDeliveryServiceException("No feed environment mapped to the name = " + name,
                ResponseCode.INVALID_FEED_ENVIRONMENT);
    }

}
