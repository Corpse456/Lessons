package com.mtvnet.dss.ivi.delivery;

import com.mtvnet.dss.ivi.delivery.conversion.ArcStageConverter;
import com.mtvnet.dss.ivi.delivery.conversion.FeedEnvironmentConverter;
import com.mtvnet.dss.ivi.delivery.conversion.FreeWheelNetworkConverter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ConversionServiceFactoryBean;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.converter.Converter;

import java.util.Arrays;
import java.util.HashSet;

@Configuration
public class ConversionConfiguration {

    @Bean
    @Qualifier("conversionServiceFactoryBean")
    public ConversionServiceFactoryBean conversionServiceFactoryBean() {
        HashSet<? extends Converter<?, ?>> converters = new HashSet<>(
                Arrays.asList(new FeedEnvironmentConverter(), new FreeWheelNetworkConverter(),
                        new ArcStageConverter()));
        ConversionServiceFactoryBean conversionServiceFactoryBean = new ConversionServiceFactoryBean();
        conversionServiceFactoryBean.setConverters(converters);
        return conversionServiceFactoryBean;
    }

    @Bean
    public ConversionService conversionService(
            @Autowired
            @Qualifier("conversionServiceFactoryBean")
            ConversionServiceFactoryBean conversionServiceFactoryBean) {
        return conversionServiceFactoryBean.getObject();
    }

}
