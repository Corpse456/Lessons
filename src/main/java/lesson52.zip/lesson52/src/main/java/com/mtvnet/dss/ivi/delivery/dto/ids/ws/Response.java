package com.mtvnet.dss.ivi.delivery.dto.ids.ws;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
@JacksonXmlRootElement(localName = "response")
public class Response {

    private ResponseSource source;
    private int code;
    private String message;
    private Object payload;

    public static Response with(ResponseSource source, ResponseCode responseCode, Object payload) {
        return new Response(source, responseCode.getCode(), responseCode.getMessage(), payload);
    }

}
