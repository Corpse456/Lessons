package com.mtvnet.dss.ivi.delivery.exception;

import com.mtvnet.dss.ivi.delivery.dto.ids.ws.ResponseCode;
import lombok.Getter;

public class IviDeliveryServiceException extends RuntimeException {

    private static final long serialVersionUID = 1151800867116403837L;

    @Getter
    private final ResponseCode responseCode;

    public IviDeliveryServiceException(ResponseCode responseCode) {
        this.responseCode = responseCode;
    }

    public IviDeliveryServiceException(String message, ResponseCode responseCode) {
        super(message);
        this.responseCode = responseCode;
    }

    public IviDeliveryServiceException(String message, Throwable cause, ResponseCode responseCode) {
        super(message, cause);
        this.responseCode = responseCode;
    }

    public IviDeliveryServiceException(Throwable cause, ResponseCode responseCode) {
        super(cause);
        this.responseCode = responseCode;
    }

    public IviDeliveryServiceException(String message, Throwable cause, boolean enableSuppression, boolean
            writableStackTrace, ResponseCode responseCode) {
        super(message, cause, enableSuppression, writableStackTrace);
        this.responseCode = responseCode;
    }

}
