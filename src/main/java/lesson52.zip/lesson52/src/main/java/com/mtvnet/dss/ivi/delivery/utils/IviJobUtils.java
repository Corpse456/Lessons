package com.mtvnet.dss.ivi.delivery.utils;

import com.mtvnet.dss.ivi.delivery.dto.fep.BviVideoDocument;
import com.mtvnet.dss.ivi.delivery.dto.ids.FeedIngestionTask;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;

import java.util.List;

public final class IviJobUtils {

    private static String freeWheelStartElement = "";
    private static String freeWheelEndElement = "";

    public static void setStaticFreewheelXmlRootElement(String email) {
        freeWheelStartElement = "<FWCoreContainer bvi_xsd_version='1' contact_email='" + email + "'>";
        freeWheelEndElement = "</FWCoreContainer>";
    }

    public static String wrapBviDocumentsToHttpPostBody(List<? extends BviVideoDocument> items) {
        StringBuilder builder = new StringBuilder();
        builder.append(freeWheelStartElement);
        for (BviVideoDocument item : items) {
            builder.append(item.getRawXmlString());
        }
        builder.append(freeWheelEndElement);
        return builder.toString();
    }

    /**
     * Convenience method for log output.
     *
     * @return "feedName/feedParam" string for FeedIngestionTask
     */
    public static String feedNameAndParam(FeedIngestionTask feedIngestionTask) {
        return String.join("/", feedIngestionTask.getFeedName(), feedIngestionTask.getFeedParamShortId());
    }

    /**
     * Convenience method for JobExecutionContext access in step.
     *
     * @return Object stored in job execution context mapped to the passed key
     */
    public static Object fromJobContextViaStepExec(StepExecution stepExec, String contextKey) {
        return stepExec.getJobExecution().getExecutionContext().get(contextKey);
    }

    public static void updateJobContextViaStepExec(StepExecution stepExec, String contextKey, Object object) {
        stepExec.getJobExecution().getExecutionContext().put(contextKey, object);
    }

    /**
     * Convenience method for JobExecutionContext access in step.
     *
     * @return Object stored in job execution context mapped to the passed key
     */
    public static Object fromJobContextViaChunkCotext(ChunkContext chunkCtx, String contextKey) {
        return chunkCtx.getStepContext().getStepExecution().getJobExecution().getExecutionContext().get(contextKey);
    }

    public static void updateJobContextViaChunkCotext(ChunkContext chunkCtx, String contextKey, Object object) {
        chunkCtx.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put(contextKey, object);
    }

}
