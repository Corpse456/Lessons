package com.mtvnet.dss.ivi.delivery.service;

import com.mtvnet.dss.ivi.delivery.dto.fep.FeedStatusElement;
import com.mtvnet.dss.ivi.delivery.dto.ids.FeedEnvironment;

import java.util.List;

public interface IFepFeedsStatusService {

    List<FeedStatusElement> retrieveFreeWheelFeedStatusList(FeedEnvironment feedEnvironment);

    FeedStatusElement retrieveFreeWheelFeedStatus(FeedEnvironment feedEnvironment, String feedName, String feedParam);

}
