package com.mtvnet.dss.ivi.delivery.utils;

import com.mtvnet.dss.ivi.delivery.dto.ids.FeedEnvironment;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.FileSystemUtils;

import java.io.File;
import java.io.IOException;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

@Slf4j
public final class IviFileUtils {

    public static File recreateJobTempDirectory(String appTempDirectory, FeedEnvironment feedEnvironment,
                                                String feedGenTimestamp, String fepDateTimeFormatPattern,
                                                String feedName, String feedParamShortId, String freewheelNetwork) {
        String timeStamp = reformatFepDateToUseInFileName(feedGenTimestamp, fepDateTimeFormatPattern);
        File jobTempDir = new File(appTempDirectory, String.join("-", feedEnvironment.getName(), feedName,
                feedParamShortId, timeStamp, freewheelNetwork));
        FileSystemUtils.deleteRecursively(jobTempDir);
        if (!jobTempDir.mkdirs()) {
            throw new RuntimeException(
                    "Unable to create temp directory for the job in parent directory = " + appTempDirectory);
        }
        return jobTempDir;
    }

    /**
     * If some IO problems just log error, leave garbage
     */
    public static void deleteDirSafelyAndLog(File dir) {
        if (dir == null || !FileSystemUtils.deleteRecursively(dir)) {
            log.error("temp directory was not deleted for unknown reason");
        } else {
            log.debug("temp directory successfully deleted");
        }
    }

    private static String reformatFepDateToUseInFileName(String feedGenTimestamp, String pattern) {
        return ZonedDateTime.parse(feedGenTimestamp, DateTimeFormatter.ofPattern(pattern))
                .format(DateTimeFormatter.ofPattern(pattern)).replaceAll(":", "-")
                .replaceAll(" ", "-");
    }

    public static File createTempXmlFileBasedOnJobParams(File tempDirectory, FeedEnvironment feedEnvironment,
                                                         String feedGenTimestamp, String fepDateTimeFormatPattern,
                                                         String feedName, String feedParamShortId) throws IOException {
        String timeStamp = reformatFepDateToUseInFileName(feedGenTimestamp, fepDateTimeFormatPattern);
        return new File(tempDirectory, String.join(
                "-", feedEnvironment.getName(), feedName, feedParamShortId, timeStamp) + ".xml");
    }

}
