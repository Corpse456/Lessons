package com.mtvnet.dss.ivi.delivery.service.implementation;

import com.mtvnet.dss.ivi.delivery.dto.arc.ArcFeedConfigurationResponse;
import com.mtvnet.dss.ivi.delivery.dto.arc.ReferencedObject;
import com.mtvnet.dss.ivi.delivery.dto.arc.ReferencedObjects;
import com.mtvnet.dss.ivi.delivery.dto.ids.ArcFeedConfiguration;
import com.mtvnet.dss.ivi.delivery.dto.ids.FeedEnvironment;
import com.mtvnet.dss.ivi.delivery.dto.ids.FreeWheelNetwork;
import com.mtvnet.dss.ivi.delivery.dto.ids.ws.ResponseCode;
import com.mtvnet.dss.ivi.delivery.exception.ArcFeedConfigurationException;
import com.mtvnet.dss.ivi.delivery.service.IArcFeedConfigurationService;
import com.mtvnet.dss.ivi.delivery.service.implementation.client.ArcFeedConfigurationClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.Validator;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Component
@Slf4j
public class ArcFeedConfigurationService implements IArcFeedConfigurationService {

    @Autowired
    private ArcFeedConfigurationClient arcFeedConfigurationClient;

    @Autowired
    private Validator validator;

    @Override
    public ArcFeedConfiguration retrieveArcIngestionConfiguration(FeedEnvironment feedEnvironment,
                                                                  String feedName) {
        ArcFeedConfigurationResponse feedConfiguration = queryFeedConfiguration(feedEnvironment, feedName);
        validateFeedConfiguration(feedConfiguration, feedName);

        ReferencedObjects referencedObjects = feedConfiguration.getResponse().getDocs().get(0).getReferencedObjects();

        List<FreeWheelNetwork> networks = retrieveFreeWheelNetworks(referencedObjects);
        String siteName = retrieveSiteName(referencedObjects);
        log.debug("Arc response: networks for the feed {} is {}.", feedName, networks);

        checkResultOrThrowException(feedName, networks);

        return new ArcFeedConfiguration(networks, siteName);
    }

    private ArcFeedConfigurationResponse queryFeedConfiguration(FeedEnvironment feedEnvironment, String feedName) {
        return arcFeedConfigurationClient.feedConfigurationByNameForFeedEnvironment(feedEnvironment, feedName);
    }

    private void validateFeedConfiguration(ArcFeedConfigurationResponse feedConfiguration, String feedName) {
        if (!validator.validate(feedConfiguration).isEmpty()) {
            log.error("Configuration for the feed {} returned by Arc is invalid.", feedName);
            throw new ArcFeedConfigurationException("Arc response failed to pass validation!",
                    ResponseCode.INVALID_FEED_CONFIGURATION);
        }
    }

    private List<FreeWheelNetwork> retrieveFreeWheelNetworks(ReferencedObjects referencedObjects) {
        Set<String> validFreeWheelNetworkTagTitles = Arrays.stream(FreeWheelNetwork.values())
                .map(FreeWheelNetwork::getAsArcTitleTagValue)
                .collect(Collectors.toSet());

        return referencedObjects.getTags().stream()
                .filter(tag -> validFreeWheelNetworkTagTitles.contains(tag.getTitle()))
                .map(tag -> FreeWheelNetwork.fromArcTitleTagValue(tag.getTitle()))
                .collect(Collectors.toList());
    }

    private String retrieveSiteName(ReferencedObjects referencedObjects) {
        List<ReferencedObject> sites = referencedObjects.getSites();
        return (sites != null) && (sites.size() == 1) ? sites.get(0).getTitle() : null;
    }

    private void checkResultOrThrowException(String feedName, List<FreeWheelNetwork> networks) {
        if (networks.size() == 0) {
            String error = "Configuration for the feed " + feedName +
                    " returned by Arc does not contain any delivery network.";
            log.error(error);
            throw new ArcFeedConfigurationException(error, ResponseCode.INVALID_FEED_CONFIGURATION);
        }
    }

}
