package com.mtvnet.dss.ivi.delivery.batch.implementation.marshalling;

import com.mtvnet.dss.ivi.delivery.dto.fep.BviVideoDocument;
import org.springframework.oxm.Unmarshaller;
import org.springframework.util.Assert;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;
import javax.xml.transform.Source;
import javax.xml.transform.stax.StAXSource;
import java.util.function.Consumer;

import static com.mtvnet.dss.ivi.delivery.batch.BatchConfigurationConstants.IVI_XML_DOC_ID_ATTR_NAME;
import static com.mtvnet.dss.ivi.delivery.batch.BatchConfigurationConstants.IVI_XML_ITEM_NAME;

public class XmlRootToStringUnmarshaller implements Unmarshaller {

    @Override
    public boolean supports(Class<?> clazz) {
        return clazz.equals(BviVideoDocument.class);
    }

    @Override
    public Object unmarshal(Source source) {
        return xmlToVideoDoc(((StAXSource) source).getXMLEventReader());
    }

    @SuppressWarnings("unchecked")
    private BviVideoDocument xmlToVideoDoc(XMLEventReader eventReader) {
        RawXmlStringConsumer rawXmlEventConsumer = new RawXmlStringConsumer();
        HashXmlStringConsumer hashXmlEventConsumer = new HashXmlStringConsumer();

        String videoDocumentId = parse(() -> eventReader, rawXmlEventConsumer.andThen(hashXmlEventConsumer));

        return new BviVideoDocument(videoDocumentId, rawXmlEventConsumer.get(), hashXmlEventConsumer.get());
    }

    private String parse(Iterable<XMLEvent> xmlEvents, Consumer<XMLEvent> xmlEventConsumer) {
        String videoDocumentId = null;
        int depth = 0;
        for (XMLEvent xmlEvent : xmlEvents) {
            if (!xmlEvent.isStartDocument()) {
                if (xmlEvent.isStartElement()) {
                    if (depth == 0) {
                        videoDocumentId = findVideoDocumentId(xmlEvent.asStartElement());
                    }
                    ++depth;
                } else if (xmlEvent.isEndElement()) {
                    --depth;
                    if (depth < 0) {
                        break;
                    }
                }
                xmlEventConsumer.accept(xmlEvent);
            }
        }
        return videoDocumentId;
    }

    private String findVideoDocumentId(StartElement startElement) {
        Assert.isTrue(IVI_XML_ITEM_NAME.equals(startElement.getName().getLocalPart()),
                "No other elements than " + IVI_XML_ITEM_NAME + " expected as xml read item");
        Attribute videoIdAttribute = startElement.getAttributeByName(QName.valueOf(IVI_XML_DOC_ID_ATTR_NAME));
        Assert.notNull(videoIdAttribute,
                IVI_XML_DOC_ID_ATTR_NAME + " attribute expected to be present at " + IVI_XML_ITEM_NAME);
        return videoIdAttribute.getValue();
    }

}
