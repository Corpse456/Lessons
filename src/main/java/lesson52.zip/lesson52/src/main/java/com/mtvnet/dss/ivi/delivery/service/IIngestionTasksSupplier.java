package com.mtvnet.dss.ivi.delivery.service;

import com.mtvnet.dss.ivi.delivery.dto.ids.FeedEnvironment;
import com.mtvnet.dss.ivi.delivery.dto.ids.FeedIngestionTask;
import com.mtvnet.dss.ivi.delivery.dto.ids.FreeWheelNetwork;

import java.util.List;

public interface IIngestionTasksSupplier {

    List<FeedIngestionTask> requestPendingIngestionTasksFor(FeedEnvironment feedEnvironment);

    FeedIngestionTask requestIngestionTaskFor(FeedEnvironment feedEnvironment, FreeWheelNetwork freeWheelNetwork,
                                              String feedName, String feedParam);

}
