package com.mtvnet.dss.ivi.delivery.service.implementation.client;

import com.mtvnet.dss.ivi.delivery.dto.ids.FeedEnvironment;
import com.mtvnet.dss.ivi.delivery.dto.ids.ws.ResponseCode;
import com.mtvnet.dss.ivi.delivery.exception.IviDeliveryServiceException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;

@Component
public class FepEnvironmentSpecificUrlBuilder {

    @Value("#{${ivi.service.fep.base.url}}")
    private Map<FeedEnvironment, URL> environmentSpecificFepBaseUrls;

    public URL environmentSpecificFepUrl(FeedEnvironment feedEnvironment, String path) {
        try {
            return new URL(environmentSpecificFepBaseUrl(feedEnvironment), path);
        } catch (MalformedURLException e) {
            throw new IviDeliveryServiceException(e, ResponseCode.IDS_UNCLASSIFIED_ERROR);
        }
    }

    private URL environmentSpecificFepBaseUrl(FeedEnvironment feedEnvironment) {
        return environmentSpecificFepBaseUrls.get(feedEnvironment);
    }

}
