package com.mtvnet.dss.ivi.delivery.service.implementation;

import com.mtvnet.dss.ivi.delivery.service.IKeyValueStorageService;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Implementation of {@link IKeyValueStorageService} backed by {@link ConcurrentHashMap}, thus storing values in memory.
 */
@Component
@Profile("local")
public class InMemoryKeyValueStorageService<K, V> implements IKeyValueStorageService<K, V> {

    private final ConcurrentHashMap<K, V> keyValueStorage = new ConcurrentHashMap<>();

    @Override
    public V get(K key) {
        return keyValueStorage.get(key);
    }

    @Override
    public V put(K key, V value) {
        return keyValueStorage.put(key, value);
    }

    @Override
    public void putAll(Map<? extends K, ? extends V> m) {
        keyValueStorage.putAll(m);
    }

    @Override
    public V remove(K key) {
        return keyValueStorage.remove(key);
    }

}
