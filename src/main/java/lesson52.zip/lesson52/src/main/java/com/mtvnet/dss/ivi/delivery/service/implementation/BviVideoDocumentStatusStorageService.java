package com.mtvnet.dss.ivi.delivery.service.implementation;

import com.mtvnet.dss.ivi.delivery.dto.fep.BviVideoDocument;
import com.mtvnet.dss.ivi.delivery.dto.fep.BviVideoDocumentDeliveryState;
import com.mtvnet.dss.ivi.delivery.dto.fep.ContentStatus;
import com.mtvnet.dss.ivi.delivery.dto.fep.DeliveryStatus;
import com.mtvnet.dss.ivi.delivery.service.IBviVideoDocumentStatusStorageService;
import com.mtvnet.dss.ivi.delivery.service.IKeyValueStorageService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
@Slf4j
public class BviVideoDocumentStatusStorageService implements IBviVideoDocumentStatusStorageService {

    @Autowired
    private IKeyValueStorageService<String, BviVideoDocumentDeliveryState> keyValueStorageService;

    public boolean awaitsUpdate(BviVideoDocument videoDocument) {
        BviVideoDocumentDeliveryState storedDeliveryState = null;
        try {
            storedDeliveryState = keyValueStorageService.get(keyFor(videoDocument));
        } catch (RuntimeException e) {
            log.error("RuntimeException encountered while trying to find delivery state:", e);
        }
        return deliveryStatus(storedDeliveryState).awaitsDelivery() || contentStatus(videoDocument,
                storedDeliveryState).awaitsUpdate();
    }

    @Override
    public void storeVideoDocumentStatus(List<? extends BviVideoDocument> videoDocuments,
                                         DeliveryStatus deliveryStatus) {
        Date deliveredAt = new Date();
        try {
            Map<String, BviVideoDocumentDeliveryState> videoDocumentStateMap = videoDocuments
                    .stream()
                    .collect(Collectors.<BviVideoDocument, String, BviVideoDocumentDeliveryState>toMap(this::keyFor,
                            videoDocument -> new BviVideoDocumentDeliveryState(videoDocument.getDocumentHash(),
                                    deliveryStatus,
                                    deliveredAt)));
            keyValueStorageService.putAll(videoDocumentStateMap);
        } catch (RuntimeException e) {
            log.error("RuntimeException encountered while trying to save delivery state:", e);
        }
    }

    private String keyFor(BviVideoDocument videoDocument) {
        return String.join(":", videoDocument.getDocumentScope(), videoDocument.getId());
    }

    private ContentStatus contentStatus(BviVideoDocument videoDocument,
                                        BviVideoDocumentDeliveryState storedDeliveryState) {
        String documentHash = videoDocument.getDocumentHash();
        String storedDocumentHash = storedDeliveryState.getDocumentHash();
        return documentHash.equals(storedDocumentHash) ? ContentStatus.UP_TO_DATE : ContentStatus.OUTDATED;
    }

    private DeliveryStatus deliveryStatus(BviVideoDocumentDeliveryState storedDeliveryState) {
        return storedDeliveryState != null ? storedDeliveryState.getDeliveryStatus() : DeliveryStatus.UNKNOWN;
    }

}
