package com.mtvnet.dss.ivi.delivery.exception;

import com.mtvnet.dss.ivi.delivery.dto.ids.ws.ResponseCode;

public class ArcFeedConfigurationException extends IviDeliveryServiceException {

    private static final long serialVersionUID = -3608850916976020267L;

    public ArcFeedConfigurationException(ResponseCode responseCode) {
        super(responseCode);
    }

    public ArcFeedConfigurationException(String message, ResponseCode responseCode) {
        super(message, responseCode);
    }

    public ArcFeedConfigurationException(String message, Throwable cause, ResponseCode responseCode) {
        super(message, cause, responseCode);
    }

    public ArcFeedConfigurationException(Throwable cause, ResponseCode responseCode) {
        super(cause, responseCode);
    }

    public ArcFeedConfigurationException(String message, Throwable cause, boolean enableSuppression, boolean
            writableStackTrace, ResponseCode responseCode) {
        super(message, cause, enableSuppression, writableStackTrace, responseCode);
    }
}
