package com.mtvnet.dss.ivi.delivery.batch.implementation;

import com.mtvnet.dss.ivi.delivery.batch.implementation.marshalling.XmlRootToStringUnmarshaller;
import com.mtvnet.dss.ivi.delivery.dto.fep.BviVideoDocument;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.batch.item.xml.StaxEventItemReader;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Component;

import java.io.File;

import static com.mtvnet.dss.ivi.delivery.batch.BatchConfigurationConstants.IVI_XML_ITEM_NAME;
import static com.mtvnet.dss.ivi.delivery.batch.BatchConfigurationConstants.JOB_CONTEXT_TEMP_BVI_FILE_KEY;
import static com.mtvnet.dss.ivi.delivery.utils.IviJobUtils.fromJobContextViaStepExec;

@Component
@JobScope
@Slf4j
public class BviItemReader extends StaxEventItemReader<BviVideoDocument> {

    public BviItemReader() {
        this.setUnmarshaller(new XmlRootToStringUnmarshaller());
        this.setFragmentRootElementName(IVI_XML_ITEM_NAME);
    }

    @BeforeStep
    public void initBasedOnJobContext(StepExecution stepExecution) {
        File bviTempFile = (File) fromJobContextViaStepExec(stepExecution, JOB_CONTEXT_TEMP_BVI_FILE_KEY);
        this.setResource(new FileSystemResource(bviTempFile));
    }

    @Override
    public void close() throws ItemStreamException {
        log.debug("BVI Xml read finished, {} items read", totalItemsReadExcludingNullItem());
        super.close();
    }

    private int totalItemsReadExcludingNullItem() {
        return this.getCurrentItemCount() - 1;
    }

}
