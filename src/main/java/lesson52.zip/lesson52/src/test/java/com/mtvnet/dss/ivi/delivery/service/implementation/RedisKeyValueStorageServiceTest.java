package com.mtvnet.dss.ivi.delivery.service.implementation;

import com.mtvnet.dss.ivi.delivery.dto.fep.BviVideoDocumentDeliveryState;
import com.mtvnet.dss.ivi.delivery.dto.fep.DeliveryStatus;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.BDDMockito;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

import java.util.Collections;
import java.util.Date;
import java.util.Map;

import static org.assertj.core.api.BDDAssertions.then;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class RedisKeyValueStorageServiceTest {

    private static final String VIDEO_DOCUMENT_ID = "42";
    private static final BviVideoDocumentDeliveryState VIDEO_DOCUMENT_STATE = new BviVideoDocumentDeliveryState(
            VIDEO_DOCUMENT_ID, DeliveryStatus.DELIVERED, new Date());
    private static final BviVideoDocumentDeliveryState PREVIOUS_VIDEO_DOCUMENT_STATE =
            new BviVideoDocumentDeliveryState("43", DeliveryStatus.DELIVERED, new Date());

    @Mock
    private RedisTemplate<String, BviVideoDocumentDeliveryState> redisTemplate;

    @Mock
    private ValueOperations<String, BviVideoDocumentDeliveryState> valueOperations;

    private RedisKeyValueStorageService<String, BviVideoDocumentDeliveryState> keyValueStorageService;

    @Before
    public void setup() {
        when(redisTemplate.opsForValue()).thenReturn(valueOperations);
        keyValueStorageService = new RedisKeyValueStorageService<>(redisTemplate);
    }

    @Test
    public void testGet() {
        given(valueOperations.get(VIDEO_DOCUMENT_ID)).willReturn(VIDEO_DOCUMENT_STATE);

        BviVideoDocumentDeliveryState deliveryState = keyValueStorageService.get(VIDEO_DOCUMENT_ID);

        then(deliveryState).isEqualTo(VIDEO_DOCUMENT_STATE);
    }

    @Test
    public void testPut() {
        given(valueOperations.get(VIDEO_DOCUMENT_ID)).willReturn(PREVIOUS_VIDEO_DOCUMENT_STATE);

        BviVideoDocumentDeliveryState deliveryState = keyValueStorageService.put(VIDEO_DOCUMENT_ID,
                VIDEO_DOCUMENT_STATE);

        BDDMockito.then(valueOperations).should().set(VIDEO_DOCUMENT_ID, VIDEO_DOCUMENT_STATE);
        then(deliveryState).isEqualTo(PREVIOUS_VIDEO_DOCUMENT_STATE);
    }

    @Test
    public void testPutAll() {
        Map<String, BviVideoDocumentDeliveryState> mapToPut = Collections.singletonMap(VIDEO_DOCUMENT_ID,
                VIDEO_DOCUMENT_STATE);

        keyValueStorageService.putAll(mapToPut);

        BDDMockito.then(valueOperations).should().multiSet(mapToPut);
    }

    @Test
    public void testRemove() {
        given(valueOperations.get(VIDEO_DOCUMENT_ID)).willReturn(PREVIOUS_VIDEO_DOCUMENT_STATE);

        BviVideoDocumentDeliveryState deliveryState = keyValueStorageService.remove(VIDEO_DOCUMENT_ID);

        BDDMockito.then(redisTemplate).should().delete(VIDEO_DOCUMENT_ID);
        then(deliveryState).isEqualTo(PREVIOUS_VIDEO_DOCUMENT_STATE);
    }

}
