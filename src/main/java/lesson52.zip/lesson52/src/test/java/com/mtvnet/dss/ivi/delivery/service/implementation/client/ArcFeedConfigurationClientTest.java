package com.mtvnet.dss.ivi.delivery.service.implementation.client;

import com.mtvnet.dss.ivi.delivery.dto.arc.ArcFeedConfigurationResponse;
import com.mtvnet.dss.ivi.delivery.dto.ids.ArcStage;
import com.mtvnet.dss.ivi.delivery.dto.ids.FeedEnvironment;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import java.net.URI;

import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class ArcFeedConfigurationClientTest {

    private static final String FEED_NAME_PLACEHOLDER = "FEED_NAME_PLACEHOLDER";
    private static final String FEED_CONFIG_REQUEST = "{\"querying_for_feed\": [[" + FEED_NAME_PLACEHOLDER + "]]}";
    private static final URI ARC_BASE_URL = URI.create("http://localhost:1234/one/two?key=value");

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private ArcFeedConfigurationClient feedConfigurationClient;

    @Test
    public void shouldHonorConfiguredArcStageAndQueryArcThroughRestTemplate() {
        ReflectionTestUtils.setField(feedConfigurationClient, "feedConfigRequest", FEED_CONFIG_REQUEST);
        ReflectionTestUtils.setField(feedConfigurationClient, "feedNamePlaceholder", FEED_NAME_PLACEHOLDER);
        ReflectionTestUtils.setField(feedConfigurationClient, "defaultArcStage", ArcStage.AUTHORING);
        ReflectionTestUtils.setField(feedConfigurationClient, "arcBaseUrl", ARC_BASE_URL);

        feedConfigurationClient.feedConfigurationByNameForFeedEnvironment(FeedEnvironment.QA, "my-favorite-feed");

        verify(restTemplate).getForObject(URI.create(ARC_BASE_URL + "&stage=authoring&q=%7B%22querying_for_feed%22:" +
                "%20%5B%5Bmy-favorite-feed%5D%5D%7D"), ArcFeedConfigurationResponse.class);
    }

}
