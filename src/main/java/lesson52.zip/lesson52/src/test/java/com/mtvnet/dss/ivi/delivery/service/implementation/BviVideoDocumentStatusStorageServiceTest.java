package com.mtvnet.dss.ivi.delivery.service.implementation;


import com.mtvnet.dss.ivi.delivery.TestUtils;
import com.mtvnet.dss.ivi.delivery.dto.fep.BviVideoDocument;
import com.mtvnet.dss.ivi.delivery.dto.fep.BviVideoDocumentDeliveryState;
import com.mtvnet.dss.ivi.delivery.dto.fep.DeliveryStatus;
import com.mtvnet.dss.ivi.delivery.service.IKeyValueStorageService;
import org.assertj.core.api.AbstractBooleanAssert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.BDDMockito;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Collections;
import java.util.Date;
import java.util.Map;
import java.util.function.Consumer;

import static org.assertj.core.api.BDDAssertions.then;
import static org.mockito.BDDMockito.willReturn;
import static org.mockito.BDDMockito.willThrow;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyMap;

@RunWith(MockitoJUnitRunner.class)
public class BviVideoDocumentStatusStorageServiceTest {

    private static final int RANDOM_STRING_LENGTH = 20;
    private static final BviVideoDocument VIDEO_DOCUMENT = videoDocument();

    @Mock
    private IKeyValueStorageService<String, BviVideoDocumentDeliveryState> keyValueStorageService;

    @InjectMocks
    private BviVideoDocumentStatusStorageService videoDocumentStatusStorageService;

    @Test
    public void shouldAwaitUpdateWhenDeliveryStateIsMissing() {
        checkFor(missingDeliveryState(), VIDEO_DOCUMENT, awaitsUpdate -> awaitsUpdate.isTrue());
    }

    @Test
    public void shouldAwaitUpdateWhenContentIsOutdatedAndDeliveryIsFailed() {
        checkFor(outdatedDeliveryState(DeliveryStatus.FAILED), VIDEO_DOCUMENT, awaitsUpdate -> awaitsUpdate.isTrue());
    }

    @Test
    public void shouldAwaitUpdateWhenContentIsUpToDateAndDeliveryIsFailed() {
        checkFor(upToDateDeliveryState(VIDEO_DOCUMENT, DeliveryStatus.FAILED), VIDEO_DOCUMENT,
                awaitsUpdate -> awaitsUpdate.isTrue());
    }

    @Test
    public void shouldAwaitUpdateWhenContentIsOutdatedAndDeliveryIsSucceeded() {
        checkFor(outdatedDeliveryState(DeliveryStatus.DELIVERED), VIDEO_DOCUMENT,
                awaitsUpdate -> awaitsUpdate.isTrue());
    }

    @Test
    public void shouldNotAwaitUpdateWhenContentIsUpToDateAndDeliveryIsSucceeded() {
        checkFor(upToDateDeliveryState(VIDEO_DOCUMENT, DeliveryStatus.DELIVERED), VIDEO_DOCUMENT,
                awaitsUpdate -> awaitsUpdate.isFalse());
    }

    private void checkFor(BviVideoDocumentDeliveryState deliveryState, BviVideoDocument videoDocument,
                          Consumer<AbstractBooleanAssert<?>> assertConsumer) {
        willReturn(deliveryState).given(keyValueStorageService).get(key(VIDEO_DOCUMENT));

        assertConsumer.accept(then(videoDocumentStatusStorageService.awaitsUpdate(VIDEO_DOCUMENT)));
    }

    @SuppressWarnings("unchecked")
    @Test
    public void shouldDelegateToKeyValueStorageForStore() {
        videoDocumentStatusStorageService.storeVideoDocumentStatus(Collections.singletonList(VIDEO_DOCUMENT),
                DeliveryStatus.DELIVERED);

        @SuppressWarnings("rawtypes")
        ArgumentCaptor<Map> captor = ArgumentCaptor.forClass(Map.class);
        BDDMockito.then(keyValueStorageService).should().putAll(captor.capture());

        BviVideoDocumentDeliveryState deliveryState = ((Map<String, BviVideoDocumentDeliveryState>) captor.getValue())
                .get(key(VIDEO_DOCUMENT));
        then(deliveryState).isNotNull();
        then(deliveryState.getDocumentHash()).isEqualTo(VIDEO_DOCUMENT.getDocumentHash());
        then(deliveryState.getDeliveryStatus()).isEqualTo(DeliveryStatus.DELIVERED);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void shouldNotThrowAnExceptionOnExceptionForStore() {
        willThrow(RuntimeException.class).given(keyValueStorageService).putAll(anyMap());

        videoDocumentStatusStorageService.storeVideoDocumentStatus(Collections.singletonList(VIDEO_DOCUMENT),
                DeliveryStatus.DELIVERED);
    }

    @Test
    public void shouldAwaitUpdateAndNotThrowAnExceptionOnExceptionForAwaitsUpdate() {
        willThrow(RuntimeException.class).given(keyValueStorageService).get(any());

        then(videoDocumentStatusStorageService.awaitsUpdate(VIDEO_DOCUMENT)).isTrue();
    }

    private static BviVideoDocument videoDocument() {
        String id = TestUtils.randomString(RANDOM_STRING_LENGTH);
        String rawXmlString = TestUtils.randomString(RANDOM_STRING_LENGTH);
        String hashXmlString = TestUtils.randomString(RANDOM_STRING_LENGTH);
        BviVideoDocument videoDocument = new BviVideoDocument(id, rawXmlString, hashXmlString);
        videoDocument.setDocumentScope(TestUtils.randomString(RANDOM_STRING_LENGTH));
        videoDocument.setDocumentHash(TestUtils.randomString(RANDOM_STRING_LENGTH));
        return videoDocument;
    }

    private static BviVideoDocumentDeliveryState missingDeliveryState() {
        return null;
    }

    private static BviVideoDocumentDeliveryState upToDateDeliveryState(BviVideoDocument videoDocument,
                                                                       DeliveryStatus deliveryStatus) {
        return new BviVideoDocumentDeliveryState(videoDocument.getDocumentHash(), deliveryStatus, new Date());
    }

    private static BviVideoDocumentDeliveryState outdatedDeliveryState(DeliveryStatus deliveryStatus) {
        return new BviVideoDocumentDeliveryState(
                TestUtils.randomString(RANDOM_STRING_LENGTH), deliveryStatus, new Date());
    }

    private static String key(BviVideoDocument videoDocument) {
        return String.join(":", videoDocument.getDocumentScope(), videoDocument.getId());
    }

}
