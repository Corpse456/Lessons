package com.mtvnet.dss.ivi.delivery.service.implementation;

import com.mtvnet.dss.ivi.delivery.dto.fep.BviVideoDocument;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.util.DigestUtils;

import java.io.UnsupportedEncodingException;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class ContentHashingServiceTest {

    private static final String HASH_XML_STRING = "HASH";
    private static final String HASH;

    static {
        try {
            HASH = DigestUtils.md5DigestAsHex(HASH_XML_STRING.getBytes("UTF-8"));
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
    }

    private ContentHashingService contentHashingService = new ContentHashingService();

    @Test
    public void shouldUseHashXmlStringToCalculateHash() {
        BviVideoDocument videoDocument = new BviVideoDocument("42", "RAW", HASH_XML_STRING);

        assertThat(contentHashingService.calculateContentHash(videoDocument)).isEqualTo(HASH);
    }

}
