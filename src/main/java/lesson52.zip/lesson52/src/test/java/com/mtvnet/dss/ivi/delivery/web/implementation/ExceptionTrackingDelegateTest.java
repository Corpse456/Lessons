package com.mtvnet.dss.ivi.delivery.web.implementation;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class ExceptionTrackingDelegateTest {

    private static final String RESPONSE_PAYLOAD = "42";

    private ExceptionTrackingDelegate exceptionTrackingDelegate = new ExceptionTrackingDelegate();

    @Test
    public void shouldReportAndGenerateEntityWithTraceReference() {
        ResponseEntity<String> responseEntity = exceptionTrackingDelegate.reportAndGenerateEntityWithTraceReference(
                null, HttpStatus.INTERNAL_SERVER_ERROR, RESPONSE_PAYLOAD);

        // It is discouraged to rename this header as API consumers may log its value to facilitate troubleshooting.
        assertThat(responseEntity.getHeaders()).containsKey("X-Trace-Reference");
        assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
    }

}
