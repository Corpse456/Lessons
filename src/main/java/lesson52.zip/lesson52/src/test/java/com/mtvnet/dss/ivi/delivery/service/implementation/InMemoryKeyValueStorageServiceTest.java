package com.mtvnet.dss.ivi.delivery.service.implementation;

import static org.mockito.BDDMockito.then;

import java.util.Collections;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.mtvnet.dss.ivi.delivery.dto.fep.BviVideoDocumentDeliveryState;
import com.mtvnet.dss.ivi.delivery.dto.fep.DeliveryStatus;

@RunWith(MockitoJUnitRunner.class)
public class InMemoryKeyValueStorageServiceTest {

    private static final String VIDEO_DOCUMENT_ID = "42";
    private static final BviVideoDocumentDeliveryState VIDEO_DOCUMENT_STATE = new BviVideoDocumentDeliveryState(
            VIDEO_DOCUMENT_ID, DeliveryStatus.DELIVERED, new Date());

    @InjectMocks
    private InMemoryKeyValueStorageService<String, BviVideoDocumentDeliveryState> keyValueStorageService;

    @Mock
    private ConcurrentHashMap<String, BviVideoDocumentDeliveryState> keyValueStorage;

    @Before
    public void setup() {
        ReflectionTestUtils.setField(keyValueStorageService, "keyValueStorage", keyValueStorage);
    }

    @Test
    public void testGet() {
        keyValueStorageService.get(VIDEO_DOCUMENT_ID);
        then(keyValueStorage).should().get(VIDEO_DOCUMENT_ID);
    }

    @Test
    public void testPut() {
        keyValueStorageService.put(VIDEO_DOCUMENT_ID,
                VIDEO_DOCUMENT_STATE);

        then(keyValueStorage).should().put(VIDEO_DOCUMENT_ID, VIDEO_DOCUMENT_STATE);
    }

    @Test
    public void testPutAll() {
        Map<String, BviVideoDocumentDeliveryState> mapToPut = Collections.singletonMap(VIDEO_DOCUMENT_ID,
                VIDEO_DOCUMENT_STATE);

        keyValueStorageService.putAll(mapToPut);

        then(keyValueStorage).should().putAll(mapToPut);
    }

    @Test
    public void testRemove() {
        keyValueStorageService.remove(VIDEO_DOCUMENT_ID);

        then(keyValueStorage).should().remove(VIDEO_DOCUMENT_ID);
    }

}
