package com.mtvnet.dss.ivi.delivery.batch.implementation.marshalling;

import com.mtvnet.dss.ivi.delivery.TestUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.oxm.UnmarshallingFailureException;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.XMLEvent;
import java.io.IOException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.willThrow;
import static org.mockito.Matchers.any;

@RunWith(MockitoJUnitRunner.class)
public class HashXmlStringConsumerTest {

    private static final String FEP_FEED_SINGLE_ITEM_CLASSPATH = "/marshalling/bviSingleItemSample.xml";
    private static final String FEP_FEED_SINGLE_ITEM_MALFORMED_CLASSPATH =
            "/marshalling/bviSingleItemMalformedSample.xml";
    private static final String FEP_FEED_HASH_SINGLE_ITEM_CLASSPATH = "/marshalling/hashBviSingleItemSample.xml";

    @Mock
    private XMLEvent xmlEvent;

    private HashXmlStringConsumer hashXmlStringConsumer;

    @Before
    public void setup() {
        hashXmlStringConsumer = new HashXmlStringConsumer();
    }

    @Test
    public void shouldProduceHashXmlStringWithRemovedTraceIdAndFeedName() throws IOException, XMLStreamException {
        TestUtils.consumeXmlEventStreamFromClassPathResource(FEP_FEED_SINGLE_ITEM_CLASSPATH, hashXmlStringConsumer);

        assertThat(hashXmlStringConsumer.get()).isEqualTo(
                TestUtils.stringFromClassPathResource(FEP_FEED_HASH_SINGLE_ITEM_CLASSPATH));
    }

    @Test(expected = UnmarshallingFailureException.class)
    public void shouldWrapXmlStreamException() throws XMLStreamException {
        willThrow(new XMLStreamException()).given(xmlEvent).writeAsEncodedUnicode(any());

        hashXmlStringConsumer.accept(xmlEvent);
    }

    @Test(expected = UnmarshallingFailureException.class)
    public void shouldThrowUnmarshallingExceptionForMalformedXml() throws XMLStreamException {
        TestUtils.consumeXmlEventStreamFromClassPathResource(FEP_FEED_SINGLE_ITEM_MALFORMED_CLASSPATH,
                hashXmlStringConsumer);
    }

}
