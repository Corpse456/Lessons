package com.mtvnet.dss.ivi.delivery.service.implementation;

import com.mtvnet.dss.ivi.delivery.dto.ids.FreeWheelNetwork;
import lombok.Data;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.util.concurrent.TimeUnit.SECONDS;
import static org.assertj.core.api.Assertions.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class RequestRateLimiterTest {

    // Given the configuration below, single test in this class will take at least 10 second to complete.
    private static final int THREAD_POOL_THREADS = 4;
    private static final long REQUESTS_LIMIT = 50;
    private static final long TPS_LIMIT = 10;
    private RequestRateLimiter requestRateLimiter = new RequestRateLimiter();

    @Before
    public void setup() throws Exception {
        ReflectionTestUtils.setField(requestRateLimiter, "tpsLimit", TPS_LIMIT);
    }

    @Test
    public void testRequestRateLimit() throws InterruptedException {
        // Two different networks, two threads per network generates 50 requests each.
        ExecutorService executorService = Executors.newFixedThreadPool(THREAD_POOL_THREADS);
        List<Future<RequestGenerationReport>> reports = executorService.invokeAll(
                Stream.of(FreeWheelNetwork.NETWORK_TEST, FreeWheelNetwork.NETWORK_TEST, FreeWheelNetwork.NETWORK_LIVE,
                        FreeWheelNetwork.NETWORK_LIVE)
                        .map(network -> new RequestGenerator(network, REQUESTS_LIMIT, requestRateLimiter))
                        .collect(Collectors.toList()));

        // Blocks current thread.
        Map<FreeWheelNetwork, List<RequestGenerationReport>> reportListByNetwork = reports.stream().map(future -> {
            try {
                return future.get();
            } catch (InterruptedException | ExecutionException e) {
                throw new RuntimeException(e);
            }
        }).collect(Collectors.groupingBy(RequestGenerationReport::getNetwork));

        // Collect TPS for a given network and assert.
        for (Map.Entry<FreeWheelNetwork, List<RequestGenerationReport>> reportList : reportListByNetwork.entrySet()) {
            long firstStartedMillis = Long.MAX_VALUE;
            long lastEndedMillis = Long.MIN_VALUE;
            long totalRequests = 0;
            for (RequestGenerationReport report : reportList.getValue()) {
                firstStartedMillis = Math.min(firstStartedMillis, report.getStartTime());
                lastEndedMillis = Math.max(lastEndedMillis, report.getEndTime());
                totalRequests += report.getRequests();
            }
            double tps = totalRequests * SECONDS.toMillis(1) / (lastEndedMillis - firstStartedMillis);
            assertThat(tps).isLessThanOrEqualTo(TPS_LIMIT);
        }
    }

    private static class RequestGenerator implements Callable<RequestGenerationReport> {

        private final FreeWheelNetwork network;
        private final long requestsLimit;
        private final RequestRateLimiter requestRateLimiter;

        RequestGenerator(FreeWheelNetwork network, long requestsLimit, RequestRateLimiter requestRateLimiter) {
            this.network = network;
            this.requestsLimit = requestsLimit;
            this.requestRateLimiter = requestRateLimiter;
        }

        @Override
        public RequestGenerationReport call() throws Exception {
            long startTime = System.currentTimeMillis();
            for (long i = 0; i < requestsLimit; i++) {
                requestRateLimiter.ensureRequestRateLimit(network);
            }
            long endTime = System.currentTimeMillis();
            return new RequestGenerationReport(network, Thread.currentThread().getName(), startTime, endTime,
                    requestsLimit);
        }

    }

    @Data
    private static class RequestGenerationReport {

        private final FreeWheelNetwork network;
        private final String thread;
        private final long startTime;
        private final long endTime;
        private final long requests;

    }

}
