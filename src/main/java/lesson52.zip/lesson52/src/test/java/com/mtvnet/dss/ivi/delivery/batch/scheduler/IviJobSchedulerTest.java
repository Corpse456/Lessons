package com.mtvnet.dss.ivi.delivery.batch.scheduler;

import com.mtvnet.dss.ivi.delivery.dto.ids.FeedEnvironment;
import com.mtvnet.dss.ivi.delivery.dto.ids.FeedIngestionTask;
import com.mtvnet.dss.ivi.delivery.service.IIngestionTaskDispatcher;
import com.mtvnet.dss.ivi.delivery.service.IIngestionTasksSupplier;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class IviJobSchedulerTest {

    @Mock
    private IIngestionTasksSupplier ingestionTasksSupplier;

    @Mock
    private IIngestionTaskDispatcher ingestionTaskDispatcher;

    @InjectMocks
    private IviJobScheduler scheduler;


    @Before
    public void setup() {
        ReflectionTestUtils.setField(scheduler, "defaultFeedEnvironment", FeedEnvironment.QA);
    }

    @Test
    public void shouldPerformIngestionDispatchIfThereArePendingTasks() {
        List<FeedIngestionTask> tasks = Arrays.asList(
                FeedIngestionTask.builder().build(), FeedIngestionTask.builder().build());
        when(ingestionTasksSupplier.requestPendingIngestionTasksFor(FeedEnvironment.QA)).thenReturn(tasks);

        scheduler.queueFeedsToDeliveryJob();

        verify(ingestionTaskDispatcher, times(2)).dispatchIngestion(any());
    }

    @Test
    public void shouldNotPerformIngestionDispatchIfThereAreNoPendingTasks() {
        when(ingestionTasksSupplier.requestPendingIngestionTasksFor(FeedEnvironment.QA)).thenReturn(Collections
                .emptyList());

        scheduler.queueFeedsToDeliveryJob();

        verify(ingestionTaskDispatcher, never()).dispatchIngestion(any());
    }

}
