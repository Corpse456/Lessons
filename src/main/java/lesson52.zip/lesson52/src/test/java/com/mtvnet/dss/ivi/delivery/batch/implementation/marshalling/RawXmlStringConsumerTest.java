package com.mtvnet.dss.ivi.delivery.batch.implementation.marshalling;

import com.mtvnet.dss.ivi.delivery.TestUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.oxm.UnmarshallingFailureException;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.XMLEvent;
import java.io.IOException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.willThrow;
import static org.mockito.Matchers.any;

@RunWith(MockitoJUnitRunner.class)
public class RawXmlStringConsumerTest {

    private static final String FEP_FEED_SINGLE_ITEM_CLASSPATH = "/marshalling/bviSingleItemSample.xml";
    private static final String FEP_FEED_RAW_SINGLE_ITEM_CLASSPATH = "/marshalling/rawBviSingleItemSample.xml";

    @Mock
    private XMLEvent xmlEvent;

    private RawXmlStringConsumer rawXmlStringConsumer;

    @Before
    public void setup() {
        rawXmlStringConsumer = new RawXmlStringConsumer();
    }

    @Test
    public void shouldProduceIdenticalRawXmlString() throws IOException, XMLStreamException {
        TestUtils.consumeXmlEventStreamFromClassPathResource(FEP_FEED_SINGLE_ITEM_CLASSPATH, rawXmlStringConsumer);

        assertThat(rawXmlStringConsumer.get()).isEqualTo(
                TestUtils.stringFromClassPathResource(FEP_FEED_RAW_SINGLE_ITEM_CLASSPATH));
    }

    @Test(expected = UnmarshallingFailureException.class)
    public void shouldWrapXmlStreamException() throws XMLStreamException {
        willThrow(new XMLStreamException()).given(xmlEvent).writeAsEncodedUnicode(any());

        rawXmlStringConsumer.accept(xmlEvent);
    }

}
