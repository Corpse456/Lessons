package com.mtvnet.dss.ivi.delivery.batch.implementation.marshalling;

import com.mtvnet.dss.ivi.delivery.TestUtils;
import com.mtvnet.dss.ivi.delivery.dto.fep.BviVideoDocument;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import javax.xml.stream.XMLStreamException;
import javax.xml.transform.stax.StAXSource;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class XmlRootToStringUnmarshallerTest {

    private static final String FEP_FEED_SINGLE_ITEM_CLASSPATH = "/marshalling/bviSingleItemSample.xml";

    private XmlRootToStringUnmarshaller xmlRootToStringUnmarshaller = new XmlRootToStringUnmarshaller();

    @Test
    public void shouldSupportBviVideoDocument() {
        assertThat(xmlRootToStringUnmarshaller.supports(BviVideoDocument.class)).isTrue();
    }

    @Test
    public void shouldCaptureVideoDocumentId() {
        TestUtils.withXmlReader(FEP_FEED_SINGLE_ITEM_CLASSPATH, reader -> {
            try {
                BviVideoDocument videoDocument = (BviVideoDocument)
                        xmlRootToStringUnmarshaller.unmarshal(new StAXSource(reader));

                assertThat(videoDocument.getId()).isEqualTo(
                        "mgid:arc:video:mtv.com:b2143299-b614-4be9-9a12-b27093698dc1");
            } catch (XMLStreamException e) {
                throw new RuntimeException(e);
            }
        });
    }

}
