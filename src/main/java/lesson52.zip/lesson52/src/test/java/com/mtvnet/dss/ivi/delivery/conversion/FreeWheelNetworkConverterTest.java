package com.mtvnet.dss.ivi.delivery.conversion;

import com.mtvnet.dss.ivi.delivery.dto.ids.FreeWheelNetwork;
import com.mtvnet.dss.ivi.delivery.exception.IviDeliveryServiceException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static org.assertj.core.api.Assertions.assertThat;


@RunWith(MockitoJUnitRunner.class)
public class FreeWheelNetworkConverterTest {

    private FreeWheelNetworkConverter freeWheelNetworkConverter = new FreeWheelNetworkConverter();

    @Test
    public void shouldSuccessfullyConvertFromValidFreeWheelNetworkName() {
        FreeWheelNetwork network = freeWheelNetworkConverter.convert(
                FreeWheelNetwork.NETWORK_TEST.getAsConfigurationProperty());

        assertThat(network).isEqualTo(FreeWheelNetwork.NETWORK_TEST);
    }

    @Test(expected = IviDeliveryServiceException.class)
    public void shouldThrowExceptionForInvalidFreeWheelNetworkName() {
        freeWheelNetworkConverter.convert("INVALID_NETWORK_NAME");
    }

}
