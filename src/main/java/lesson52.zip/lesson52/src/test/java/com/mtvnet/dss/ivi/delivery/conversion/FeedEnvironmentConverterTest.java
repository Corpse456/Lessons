package com.mtvnet.dss.ivi.delivery.conversion;

import com.mtvnet.dss.ivi.delivery.dto.ids.FeedEnvironment;
import com.mtvnet.dss.ivi.delivery.exception.IviDeliveryServiceException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class FeedEnvironmentConverterTest {

    private FeedEnvironmentConverter feedEnvironmentConverter = new FeedEnvironmentConverter();

    @Test
    public void shouldSuccessfullyConvertFromValidFeedEnvironmentName() {
        FeedEnvironment feedEnvironment = feedEnvironmentConverter.convert(FeedEnvironment.QA.getName());

        assertThat(feedEnvironment).isEqualTo(FeedEnvironment.QA);
    }

    @Test(expected = IviDeliveryServiceException.class)
    public void shouldThrowExceptionForInvalidFeedEnvironmentName() {
        feedEnvironmentConverter.convert("INVALID_FEED_ENVIRONMENT");
    }

}
