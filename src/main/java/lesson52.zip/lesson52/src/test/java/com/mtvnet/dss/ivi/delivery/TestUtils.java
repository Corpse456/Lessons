package com.mtvnet.dss.ivi.delivery;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Charsets;
import com.google.common.io.Resources;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.XMLEvent;
import java.io.IOException;
import java.io.InputStream;
import java.util.Random;
import java.util.function.Consumer;
import java.util.stream.Collectors;

public class TestUtils {

    private static final int CHUNK_SIZE = 10;
    private static final Random RANDOM = new Random();
    private static ObjectMapper jsonMapper = new ObjectMapper();

    public static <T> T classPathJsonResourceToObject(String classPathResource, Class<T> clazz) throws Exception {
        InputStream in = classPathResourceAsInputStream(classPathResource);
        return jsonMapper.readValue(in, clazz);
    }

    public static String stringFromClassPathResource(String classPathResource) {
        try {
            return Resources.toString(Resources.getResource(TestUtils.class, classPathResource), Charsets.UTF_8);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @SuppressWarnings("unchecked")
    public static void consumeXmlEventStreamFromClassPathResource(String classPathResource,
                                                                  Consumer<XMLEvent> consumer) {
        withXmlReader(classPathResource, reader -> ((Iterable<XMLEvent>) () -> reader).forEach(consumer));
    }

    public static void withXmlReader(String classPathResource, Consumer<XMLEventReader> consumer) {
        try (InputStream in = classPathResourceAsInputStream(classPathResource)) {
            XMLInputFactory factory = XMLInputFactory.newInstance();
            XMLEventReader reader = factory.createXMLEventReader(in);
            try {
                consumer.accept(reader);
            } finally {
                reader.close();
            }
        } catch (XMLStreamException | IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static InputStream classPathResourceAsInputStream(String classPathResource) {
        return TestUtils.class.getResourceAsStream(classPathResource);
    }

    public static String randomString(int length) {
        return RANDOM.ints(length, 0, CHUNK_SIZE)
                .mapToObj(String::valueOf)
                .collect(Collectors.joining());
    }

}
