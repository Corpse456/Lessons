package com.mtvnet.dss.ivi.delivery.web;

import com.mtvnet.dss.ivi.delivery.dto.ids.FreeWheelNetwork;
import com.mtvnet.dss.ivi.delivery.dto.ids.ws.Response;
import com.mtvnet.dss.ivi.delivery.dto.ids.ws.ResponseCode;
import com.mtvnet.dss.ivi.delivery.dto.ids.ws.ResponseSource;
import com.mtvnet.dss.ivi.delivery.exception.ThirdPartySystemAccessException;
import com.mtvnet.dss.ivi.delivery.service.IFreeWheelDeliveryService;
import com.mtvnet.dss.ivi.delivery.web.implementation.SyncErrorResponseProducer;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.BDDMockito;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;

import static org.assertj.core.api.BDDAssertions.then;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class SyncControllerTest {

    private static final ThirdPartySystemAccessException EXCEPTION =
            new ThirdPartySystemAccessException(ResponseCode.THIRDPARTY_SYSTEM_UNCLASSIFIED_ERROR);

    private static final ResponseEntity<Response> BAD_REQUEST_RESPONSE = ResponseEntity.badRequest()
            .body(Response.with(ResponseSource.IDS, ResponseCode.INVALID_FREEWHEEL_NETWORK, null));

    private static final String PAYLOAD = "42";

    private static final FreeWheelNetwork FREEWHEEL_NETWORK = FreeWheelNetwork.NETWORK_TEST;

    @Mock
    private IFreeWheelDeliveryService freeWheelDeliveryService;

    @Mock
    private SyncErrorResponseProducer syncErrorResponseProducer;

    @InjectMocks
    private SyncController syncController;

    @Test
    public void shouldDelegateExceptionProcessingToSyncErrorResponseProducer() {
        when(syncErrorResponseProducer.produceErrorResponse(EXCEPTION)).thenReturn(BAD_REQUEST_RESPONSE);

        ResponseEntity<Response> responseEntity = syncController.handleFreeWheelDeliveryException(EXCEPTION);

        then(responseEntity).isEqualTo(BAD_REQUEST_RESPONSE);
    }

    @Test
    public void shouldProceedWithValidFreeWheelNetwork() {
        ResponseEntity<Response> responseEntity =
                syncController.ingest(FREEWHEEL_NETWORK.getAsArcTitleTagValue(), PAYLOAD);

        BDDMockito.then(freeWheelDeliveryService).should().ingestIviDocuments(PAYLOAD, FREEWHEEL_NETWORK);
        then(responseEntity).isEqualTo(ResponseEntity.ok().build());
    }


    @Test
    public void shouldRejectInvalidFreeWheelNetwork() {
        ResponseEntity<Response> responseEntity =
                syncController.ingest("invalid-freewheel-network", PAYLOAD);

        BDDMockito.then(freeWheelDeliveryService).should(never()).ingestIviDocuments((String) any(), any());
        then(responseEntity).isEqualTo(BAD_REQUEST_RESPONSE);
    }

}
