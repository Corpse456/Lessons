package com.mtvnet.dss.ivi.delivery.batch.scheduler;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.test.util.ReflectionTestUtils;

import com.mtvnet.dss.ivi.delivery.dto.ids.FeedIngestionTask;
import com.mtvnet.dss.ivi.delivery.service.IJobParametersFactory;

public class FeedsDeliveryQueueTest {

    private static final Job IVI_JOB = mock(Job.class);

    private static final FeedIngestionTask VALID_TASK = mock(FeedIngestionTask.class);
    private static final FeedIngestionTask INVALID_TASK = mock(FeedIngestionTask.class);
    private static final FeedIngestionTask PREVIOUS_FAIL_TASK = mock(FeedIngestionTask.class);
    private static final FeedIngestionTask PREVIOUS_COMPLETE_TASK = mock(FeedIngestionTask.class);

    private static final JobParameters VALID_PARAMETERS = mock(JobParameters.class);
    private static final JobParameters INVALID_PARAMETERS = mock(JobParameters.class);
    private static final JobParameters PREVIOUS_FAIL_PARAMETERS = mock(JobParameters.class);
    private static final JobParameters PREVIOUS_COMPLETE_PARAMETERS = mock(JobParameters.class);

    private static final JobExecution CURRENT_SUCCESS_EXECUTION = mock(JobExecution.class);
    private static final JobExecution CURRENT_FAIL_EXECUTION = mock(JobExecution.class);
    private static final JobExecution RESTART_EXECUTION = mock(JobExecution.class);

    private static final ExitStatus STATUS_UNPREDICTABLE_FAIL_OR_COMPLETE = Math.random() > (1.0 / 2)
            ? ExitStatus.COMPLETED : ExitStatus.FAILED;

    private Map<FeedIngestionTask, Future<ExitStatus>> deliveryResults = new HashMap<>();

    private IJobParametersFactory jobParametersFactory = mock(IJobParametersFactory.class);
    private JobLauncher jobLauncher = mock(JobLauncher.class);

    private FeedsDeliveryQueue feedsDeliveryQueue;

    @Before
    public void setUp() throws Exception {
        feedsDeliveryQueue = new FeedsDeliveryQueue(jobParametersFactory, jobLauncher, IVI_JOB);
        deliveryResults = new HashMap<>();
        ReflectionTestUtils.setField(feedsDeliveryQueue, "deliveryResults", deliveryResults);
        configureMocks();
    }

    @SuppressWarnings("unchecked")
    private void configureMocks() throws Exception {
        when(jobParametersFactory.createJobParameters(VALID_TASK)).thenReturn(VALID_PARAMETERS);
        when(jobParametersFactory.createJobParameters(INVALID_TASK)).thenReturn(INVALID_PARAMETERS);
        when(jobParametersFactory.createJobParameters(PREVIOUS_FAIL_TASK)).thenReturn(PREVIOUS_FAIL_PARAMETERS);
        when(jobParametersFactory.createJobParameters(PREVIOUS_COMPLETE_TASK)).thenReturn(PREVIOUS_COMPLETE_PARAMETERS);

        when(jobLauncher.run(IVI_JOB, VALID_PARAMETERS)).thenReturn(CURRENT_SUCCESS_EXECUTION);
        when(jobLauncher.run(IVI_JOB, INVALID_PARAMETERS)).thenReturn(CURRENT_FAIL_EXECUTION);
        when(jobLauncher.run(IVI_JOB, PREVIOUS_FAIL_PARAMETERS)).thenReturn(RESTART_EXECUTION);
        when(jobLauncher.run(IVI_JOB, PREVIOUS_COMPLETE_PARAMETERS))
                .thenThrow(JobInstanceAlreadyCompleteException.class);

        when(CURRENT_SUCCESS_EXECUTION.getExitStatus()).thenReturn(ExitStatus.COMPLETED);
        when(CURRENT_FAIL_EXECUTION.getExitStatus()).thenReturn(ExitStatus.FAILED);
        when(RESTART_EXECUTION.getExitStatus()).thenReturn(STATUS_UNPREDICTABLE_FAIL_OR_COMPLETE);
    }

    @Test()
    public void shouldSuccessOnValidTask() throws Exception {
        feedsDeliveryQueue.addFeed(VALID_TASK);
        ExitStatus result = waitForAsyncResultForTask(deliveryResults, VALID_TASK);

        verify(jobLauncher, times(1)).run(any(), any());
        assertThat(result).isEqualTo(ExitStatus.COMPLETED);
    }

    @Test()
    public void shouldRestartPreviouslyFailedTask() throws Exception {
        feedsDeliveryQueue.addFeed(PREVIOUS_FAIL_TASK);
        ExitStatus result = waitForAsyncResultForTask(deliveryResults, PREVIOUS_FAIL_TASK);

        verify(jobLauncher, times(1)).run(any(), any());
        assertThat(result).isEqualTo(STATUS_UNPREDICTABLE_FAIL_OR_COMPLETE);
    }

    @Test()
    public void shouldFailOnInvalidTask() throws Exception {
        feedsDeliveryQueue.addFeed(INVALID_TASK);
        ExitStatus result = waitForAsyncResultForTask(deliveryResults, INVALID_TASK);

        verify(jobLauncher, times(1)).run(any(), any());
        assertThat(result).isEqualTo(ExitStatus.FAILED);
    }

    @Test(expected = JobInstanceAlreadyCompleteException.class)
    public void shouldHandleExceptionAndReturnSuccessOnRestartCompleted() throws Exception {
        feedsDeliveryQueue.addFeed(PREVIOUS_COMPLETE_TASK);
        ExitStatus result = waitForAsyncResultForTask(deliveryResults, PREVIOUS_COMPLETE_TASK);

        assertThat(result).isEqualTo(ExitStatus.COMPLETED);
        verify(jobLauncher).run(IVI_JOB, PREVIOUS_COMPLETE_PARAMETERS);
        verify(jobLauncher.run(IVI_JOB, PREVIOUS_COMPLETE_PARAMETERS));
    }

    @Test(expected = IllegalArgumentException.class)
    public void shouldThrowExceptionOnNullTask() {
        feedsDeliveryQueue.addFeed(null);
    }

    @Test()
    public void doNothingIfAlreadyQueued() throws Exception {
        deliveryResults.put(VALID_TASK, CompletableFuture.completedFuture(ExitStatus.UNKNOWN));

        feedsDeliveryQueue.addFeed(VALID_TASK);

        verify(jobLauncher, times(0)).run(any(), any());
    }

    private static ExitStatus waitForAsyncResultForTask(Map<FeedIngestionTask, Future<ExitStatus>> deliveryResults,
            FeedIngestionTask task) throws InterruptedException, ExecutionException, TimeoutException {
        return deliveryResults.get(task).get(1L, TimeUnit.SECONDS);
    }

}
