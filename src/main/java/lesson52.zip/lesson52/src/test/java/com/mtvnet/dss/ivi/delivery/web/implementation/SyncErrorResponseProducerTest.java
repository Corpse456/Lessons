package com.mtvnet.dss.ivi.delivery.web.implementation;

import com.mtvnet.dss.ivi.delivery.dto.ids.ws.Response;
import com.mtvnet.dss.ivi.delivery.dto.ids.ws.ResponseCode;
import com.mtvnet.dss.ivi.delivery.dto.ids.ws.ResponseSource;
import com.mtvnet.dss.ivi.delivery.exception.ThirdPartySystemAccessException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpClientErrorException;

import java.nio.charset.Charset;

import static org.mockito.BDDMockito.then;

@RunWith(MockitoJUnitRunner.class)
public class SyncErrorResponseProducerTest {

    private static final String RESPONSE_PAYLOAD = "42";

    @Mock
    private ExceptionTrackingDelegate exceptionTrackingDelegate;

    @InjectMocks
    private SyncErrorResponseProducer syncErrorResponseProducer;

    @Test
    public void shouldReturn500WithNoPayloadAndPreserveResponseCodeForRuntimeException() {

        Exception cause = new RuntimeException();

        verifyForExceptionCause(cause, HttpStatus.INTERNAL_SERVER_ERROR,
                ResponseCode.THIRDPARTY_SYSTEM_UNCLASSIFIED_ERROR, null);
    }

    @Test
    public void shouldPropagate400FromThirdPartyWithPayloadAndOverridenResponseCodeForHttpClientErrorException() {

        Exception cause = new HttpClientErrorException(HttpStatus.BAD_REQUEST,
                HttpStatus.BAD_REQUEST.getReasonPhrase(), RESPONSE_PAYLOAD.getBytes(),
                Charset.defaultCharset());

        verifyForExceptionCause(cause, HttpStatus.BAD_REQUEST, ResponseCode.THIRDPARTY_SYSTEM_BAD_REQUEST,
                RESPONSE_PAYLOAD);
    }

    @Test
    public void shouldNotPropagate404FromThirdPartyWithNoPayloadAndPreserveResponseCodeForHttpClientErrorException() {

        Exception cause = new HttpClientErrorException(HttpStatus.NOT_FOUND,
                HttpStatus.NOT_FOUND.getReasonPhrase(), RESPONSE_PAYLOAD.getBytes(),
                Charset.defaultCharset());

        verifyForExceptionCause(cause, HttpStatus.INTERNAL_SERVER_ERROR, ResponseCode
                .THIRDPARTY_SYSTEM_UNCLASSIFIED_ERROR, null);
    }

    private void verifyForExceptionCause(Exception cause, HttpStatus expectedStatusCode,
                                         ResponseCode expectedResponseCode, String expectedPayload) {

        ThirdPartySystemAccessException exception = new ThirdPartySystemAccessException(cause,
                ResponseCode.THIRDPARTY_SYSTEM_UNCLASSIFIED_ERROR);

        syncErrorResponseProducer.produceErrorResponse(exception);

        then(exceptionTrackingDelegate).should().reportAndGenerateEntityWithTraceReference(exception,
                expectedStatusCode, Response.with(ResponseSource.FREEWHEEL, expectedResponseCode, expectedPayload));
    }

}
