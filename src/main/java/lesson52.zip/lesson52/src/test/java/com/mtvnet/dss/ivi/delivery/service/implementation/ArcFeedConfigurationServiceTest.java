package com.mtvnet.dss.ivi.delivery.service.implementation;

import static com.mtvnet.dss.ivi.delivery.TestUtils.classPathJsonResourceToObject;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import com.mtvnet.dss.ivi.delivery.exception.ArcFeedConfigurationException;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.mtvnet.dss.ivi.delivery.dto.arc.ArcFeedConfigurationResponse;
import com.mtvnet.dss.ivi.delivery.dto.ids.ArcFeedConfiguration;
import com.mtvnet.dss.ivi.delivery.dto.ids.FeedEnvironment;
import com.mtvnet.dss.ivi.delivery.dto.ids.FreeWheelNetwork;
import com.mtvnet.dss.ivi.delivery.exception.IviDeliveryServiceException;
import com.mtvnet.dss.ivi.delivery.service.implementation.client.ArcFeedConfigurationClient;

@RunWith(MockitoJUnitRunner.class)
public class ArcFeedConfigurationServiceTest {
    private static final String FEED_NAME_SINGLE_NET = "feed1";
    private static final String FEED_NAME_MULTI_NET = "feed2";

    private static final FeedEnvironment FEED_ENV_QA = FeedEnvironment.QA;
    private static final FeedEnvironment FEED_ENV_LIVE = FeedEnvironment.LIVE;

    private static final String ARC_CONFIG_SINGLE_NET = "/arcFeedConfigResponseSingleNet.json";
    private static final String ARC_CONFIG_MULTI_NET = "/arcFeedConfigResponseMultiNet.json";
    private static final String ARC_CONFIG_EMPTY_NET = "/arcFeedConfigResponseEmptyNet.json";

    private ArcFeedConfigurationResponse configStubNoStageSingle;
    private ArcFeedConfigurationResponse configStubLiveMulti;
    private ArcFeedConfigurationResponse configStubNoStageEmpty;

    @Mock
    private ArcFeedConfigurationClient arcFeedConfigurationClient;

    @Mock
    private Validator validator;

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @InjectMocks
    private ArcFeedConfigurationService arcService;

    @Before
    public void setUp() throws Exception {
        ReflectionTestUtils.setField(arcService, "validator", validator);

        configStubNoStageSingle = classPathJsonResourceToObject(ARC_CONFIG_SINGLE_NET,
                ArcFeedConfigurationResponse.class);
        configStubLiveMulti = classPathJsonResourceToObject(ARC_CONFIG_MULTI_NET, ArcFeedConfigurationResponse.class);
        configStubNoStageEmpty = classPathJsonResourceToObject(ARC_CONFIG_EMPTY_NET,
                ArcFeedConfigurationResponse.class);
    }

    @Test
    public void correctMultiResponseFromLive() {
        given((arcFeedConfigurationClient.feedConfigurationByNameForFeedEnvironment(FEED_ENV_LIVE, FEED_NAME_MULTI_NET)))
                .willReturn(configStubLiveMulti);

        ArcFeedConfiguration result = arcService.retrieveArcIngestionConfiguration(FEED_ENV_LIVE, FEED_NAME_MULTI_NET);

        assertThat(result.getFreeWheelNetworks()).size().isEqualTo(2);
        assertThat(result.getFreeWheelNetworks()).contains(FreeWheelNetwork.NETWORK_TEST);
        assertThat(result.getFreeWheelNetworks()).contains(FreeWheelNetwork.NETWORK_LIVE);
    }

    @Test
    public void correctSingleResponseFromQa() {
        given(arcFeedConfigurationClient.feedConfigurationByNameForFeedEnvironment(FEED_ENV_QA, FEED_NAME_SINGLE_NET))
                .willReturn(configStubNoStageSingle);

        ArcFeedConfiguration result = arcService.retrieveArcIngestionConfiguration(FEED_ENV_QA, FEED_NAME_SINGLE_NET);

        assertThat(result.getFreeWheelNetworks()).size().isEqualTo(1);
        assertThat(result.getFreeWheelNetworks()).contains(FreeWheelNetwork.NETWORK_TEST);
    }

    @Test
    public void shouldThrowExceptionOnNoNetwork() {
        given(arcFeedConfigurationClient.feedConfigurationByNameForFeedEnvironment(any(), any()))
                .willReturn(configStubNoStageEmpty);
        thrown.expect(ArcFeedConfigurationException.class);
        thrown.expectMessage("does not contain any delivery network");

        arcService.retrieveArcIngestionConfiguration(FEED_ENV_QA, FEED_NAME_SINGLE_NET);


        then(arcFeedConfigurationClient).should(times(1))
                .feedConfigurationByNameForFeedEnvironment(FEED_ENV_QA, FEED_NAME_SINGLE_NET);

    }

    @SuppressWarnings("unchecked")
    @Test
    public void shouldThrowExceptionOnInvalidConfiguration() {
        ArcFeedConfigurationResponse stubResponse = configStubNoStageSingle;
        Set<ConstraintViolation<ArcFeedConfigurationResponse>> violationSetMock = mock(Set.class);
        given(arcFeedConfigurationClient.feedConfigurationByNameForFeedEnvironment(any(), any()))
                .willReturn(configStubNoStageSingle);
        given(violationSetMock.isEmpty()).willReturn(false);
        given(validator.validate(stubResponse)).willReturn(violationSetMock);
        thrown.expect(ArcFeedConfigurationException.class);
        thrown.expectMessage("Arc response failed to pass validation");

        arcService.retrieveArcIngestionConfiguration(FEED_ENV_QA, FEED_NAME_SINGLE_NET);

        then(arcFeedConfigurationClient).should(times(1))
                .feedConfigurationByNameForFeedEnvironment(FEED_ENV_QA, FEED_NAME_SINGLE_NET);

    }

}
