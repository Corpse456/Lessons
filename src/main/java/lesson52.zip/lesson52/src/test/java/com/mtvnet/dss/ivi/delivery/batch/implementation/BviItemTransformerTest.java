package com.mtvnet.dss.ivi.delivery.batch.implementation;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

import java.io.InputStream;
import java.nio.charset.Charset;

import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.io.ClassPathResource;
import org.springframework.test.util.ReflectionTestUtils;

import com.mtvnet.dss.ivi.delivery.dto.fep.BviVideoDocument;
import com.mtvnet.dss.ivi.delivery.service.IContentHashingService;

@RunWith(MockitoJUnitRunner.class)
public class BviItemTransformerTest {
    
    private static final ClassPathResource VIDEO_DOCUMENT_SAMPLE_XML = new ClassPathResource("marshalling/bviSingleItemSample.xml");
    private static final String EXPECTED_HASH_STUB = "FF";
    
    private BviVideoDocument videoDocument;
    
    private String categoryName = "freewheel";
    private String siteName = "mtv.com";
    private String feedName = "someFeed";
    private String freeWheelNetwork = "freewheel-test-network";

    @Mock
    private IContentHashingService contentHashingService;
    
    @InjectMocks
    BviItemTransformer itemTransformer;

    @Before
    public void setUp() throws Exception {
        ReflectionTestUtils.setField(itemTransformer, "categoryName", categoryName);
        ReflectionTestUtils.setField(itemTransformer, "siteName", siteName);
        ReflectionTestUtils.setField(itemTransformer, "feedName", feedName);
        ReflectionTestUtils.setField(itemTransformer, "freeWheelNetwork", freeWheelNetwork);
        
        String rawXml = null;
        try (InputStream in = VIDEO_DOCUMENT_SAMPLE_XML.getInputStream()) {
            rawXml = IOUtils.toString(in, Charset.forName("UTF-8"));
        }
        String hashXml = removeMetadata(rawXml);
        
        videoDocument = new BviVideoDocument("id", rawXml, hashXml);
    }

    @Test
    public void shouldSetContentHash() throws Exception {
        given(contentHashingService.calculateContentHash(videoDocument))
            .willReturn(EXPECTED_HASH_STUB);
        String expectedScopeStub = String.join(":", categoryName, siteName, feedName, freeWheelNetwork);
        
        itemTransformer.process(videoDocument);
        
        assertThat(videoDocument.getDocumentHash()).isEqualTo(EXPECTED_HASH_STUB);
        assertThat(videoDocument.getDocumentScope()).isEqualTo(expectedScopeStub);
    }
    
    /**
     * it has no influence on tested class required behavior. This method is just illustration of real data.
     */
    private String removeMetadata(String rawXml) {
        return rawXml;
    }


}
