package com.mtvnet.dss.ivi.delivery.service.implementation.client;

import com.mtvnet.dss.ivi.delivery.dto.ids.FeedEnvironment;
import com.mtvnet.dss.ivi.delivery.exception.IviDeliveryServiceException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class FepEnvironmentSpecificUrlBuilderTest {

    private static final Map<FeedEnvironment, URL> ENVIRONMENT_SPECIFIC_BASE_URLS = new HashMap<>(2);

    static {
        try {
            ENVIRONMENT_SPECIFIC_BASE_URLS.put(FeedEnvironment.QA, new URL("http://qa.localhost:1234/"));
            ENVIRONMENT_SPECIFIC_BASE_URLS.put(FeedEnvironment.LIVE, new URL("http://localhost:1234/"));
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }

    private FepEnvironmentSpecificUrlBuilder environmentSpecificUrlBuilder = new FepEnvironmentSpecificUrlBuilder();

    @Before
    public void setup() {
        ReflectionTestUtils.setField(environmentSpecificUrlBuilder, "environmentSpecificFepBaseUrls",
                ENVIRONMENT_SPECIFIC_BASE_URLS);
    }

    @Test
    public void shouldProvideCorrectEnvironmentSpecificUrl() throws MalformedURLException {
        URL url = environmentSpecificUrlBuilder.environmentSpecificFepUrl(FeedEnvironment.QA, "/download?format");

        assertThat(url).isEqualTo(new URL("http://qa.localhost:1234/download?format"));
    }

    @Test(expected = IviDeliveryServiceException.class)
    public void shouldThrowIviDeliveryServiceExceptionForMalformedUrl() throws MalformedURLException {
        environmentSpecificUrlBuilder.environmentSpecificFepUrl(FeedEnvironment.LIVE, null);
    }

}
