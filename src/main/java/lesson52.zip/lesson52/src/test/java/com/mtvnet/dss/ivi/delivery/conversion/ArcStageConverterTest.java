package com.mtvnet.dss.ivi.delivery.conversion;

import com.mtvnet.dss.ivi.delivery.dto.ids.ArcStage;
import com.mtvnet.dss.ivi.delivery.exception.IviDeliveryServiceException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class ArcStageConverterTest {

    private ArcStageConverter arcStageConverter = new ArcStageConverter();

    @Test
    public void shouldSuccessfullyConvertFromValidArcStageName() {
        ArcStage arcStage = arcStageConverter.convert(ArcStage.AUTHORING.getName());

        assertThat(arcStage).isEqualTo(ArcStage.AUTHORING);
    }

    @Test(expected = IviDeliveryServiceException.class)
    public void shouldThrowExceptionForInvalidArcStageName() {
        arcStageConverter.convert("INVALID_ARC_STAGE");
    }

}
