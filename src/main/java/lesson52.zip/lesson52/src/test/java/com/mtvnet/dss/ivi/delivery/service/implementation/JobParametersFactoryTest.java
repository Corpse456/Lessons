package com.mtvnet.dss.ivi.delivery.service.implementation;

import com.mtvnet.dss.ivi.delivery.dto.ids.FeedEnvironment;
import com.mtvnet.dss.ivi.delivery.dto.ids.FeedIngestionTask;
import com.mtvnet.dss.ivi.delivery.dto.ids.FreeWheelNetwork;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.batch.core.JobParameters;

import static com.mtvnet.dss.ivi.delivery.batch.BatchConfigurationConstants.*;
import static org.assertj.core.api.Assertions.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class JobParametersFactoryTest {

    private FeedIngestionTask feedIngestionTask = FeedIngestionTask.builder()
            .freeWheelNetwork(FreeWheelNetwork.NETWORK_TEST)
            .feedEnvironment(FeedEnvironment.QA)
            .category("CATEGORY")
            .siteName("SITE")
            .feedName("FEED_NAME")
            .feedParamShortId("FEED_PARAM")
            .feedGenTimestamp("FEED_TIMESTAMP")
            .build();

    private JobParametersFactory jobParametersFactory = new JobParametersFactory();

    @Test
    public void shouldCaptureAllParametersFromFeedIngestionTask() {
        JobParameters jobParameters = jobParametersFactory.createJobParameters(feedIngestionTask);

        assertThat(jobParameters.getString(JOB_PARAMETER_FREEWHEEL_NETWORK)).isEqualTo(FreeWheelNetwork.NETWORK_TEST
                .getAsJobParameter());
        assertThat(jobParameters.getString(JOB_PARAMETER_FEED_ENVIRONMENT)).isEqualTo(FeedEnvironment.QA.getName());
        assertThat(jobParameters.getString(JOB_PARAMETER_CATEGORY_NAME)).isEqualTo("CATEGORY");
        assertThat(jobParameters.getString(JOB_PARAMETER_SITE_NAME)).isEqualTo("SITE");
        assertThat(jobParameters.getString(JOB_PARAMETER_FEED_NAME)).isEqualTo("FEED_NAME");
        assertThat(jobParameters.getString(JOB_PARAMETER_FEED_PARAM_SHORT_ID)).isEqualTo("FEED_PARAM");
        assertThat(jobParameters.getString(JOB_PARAMETER_FEED_GEN_TIMESTAMP)).isEqualTo("FEED_TIMESTAMP");
    }

}
