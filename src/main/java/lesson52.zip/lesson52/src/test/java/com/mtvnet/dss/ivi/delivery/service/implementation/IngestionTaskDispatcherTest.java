package com.mtvnet.dss.ivi.delivery.service.implementation;

import com.mtvnet.dss.ivi.delivery.batch.scheduler.FeedsDeliveryQueue;
import com.mtvnet.dss.ivi.delivery.dto.ids.FeedIngestionTask;
import com.mtvnet.dss.ivi.delivery.dto.ids.FreeWheelNetwork;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Collections;

import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class IngestionTaskDispatcherTest {

    @Mock
    private FeedsDeliveryQueue feedsDeliveryQueue;

    private IngestionTaskDispatcher ingestionTaskDispatcher = new IngestionTaskDispatcher();

    @Test
    public void shouldAddToQueueForAGivenFreeWheelNetwork() {
        ReflectionTestUtils.setField(ingestionTaskDispatcher, "networkQueues", Collections.singletonMap(
                FreeWheelNetwork.NETWORK_TEST, feedsDeliveryQueue));

        FeedIngestionTask feedIngestionTask =
                FeedIngestionTask.builder().freeWheelNetwork(FreeWheelNetwork.NETWORK_TEST).build();

        ingestionTaskDispatcher.dispatchIngestion(feedIngestionTask);

        verify(feedsDeliveryQueue).addFeed(feedIngestionTask);
    }

}
