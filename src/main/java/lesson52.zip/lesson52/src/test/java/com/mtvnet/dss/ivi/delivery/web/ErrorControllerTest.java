package com.mtvnet.dss.ivi.delivery.web;

import com.mtvnet.dss.ivi.delivery.dto.ids.ws.Response;
import com.mtvnet.dss.ivi.delivery.dto.ids.ws.ResponseCode;
import com.mtvnet.dss.ivi.delivery.dto.ids.ws.ResponseSource;
import com.mtvnet.dss.ivi.delivery.web.implementation.ExceptionTrackingDelegate;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.boot.autoconfigure.web.BasicErrorController;
import org.springframework.boot.autoconfigure.web.DefaultErrorAttributes;
import org.springframework.boot.autoconfigure.web.ErrorProperties;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Collections;

import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;

@RunWith(MockitoJUnitRunner.class)
public class ErrorControllerTest {

    private static final String RESPONSE_PAYLOAD = "42";

    @Mock
    private ExceptionTrackingDelegate exceptionTrackingDelegate;

    @Mock
    private BasicErrorController basicErrorController;

    @Mock
    private HttpServletRequest httpServletRequest;

    @Mock
    private HttpServletResponse httpServletResponse;

    @InjectMocks
    private ErrorController errorController = new ErrorController(new DefaultErrorAttributes(), new ErrorProperties(),
            Collections.emptyList());

    @Test
    public void shouldDelegateHtmlErrorPageRenderingToBasicErrorController() {
        errorController.errorHtml(httpServletRequest, httpServletResponse);

        then(basicErrorController).should().errorHtml(httpServletRequest, httpServletResponse);
    }

    @Test
    public void shouldDelegateApiErrorHandlingToExceptionTrackingDelegate() {
        given(basicErrorController.error(httpServletRequest)).willReturn(ResponseEntity.badRequest().body(Collections
                .singletonMap("message", RESPONSE_PAYLOAD)));

        errorController.error(httpServletRequest);

        then(exceptionTrackingDelegate).should().reportAndGenerateEntityWithTraceReference(null,
                HttpStatus.BAD_REQUEST,
                Response.with(ResponseSource.IDS, ResponseCode.IDS_UNCLASSIFIED_ERROR, RESPONSE_PAYLOAD));
    }

    @Test
    public void shouldDelegateErrorPathRetrievalToBasicErrorController() {
        errorController.getErrorPath();

        then(basicErrorController).should().getErrorPath();
    }

}
