package com.mtvnet.dss.ivi.delivery.service.implementation.client;

import com.mtvnet.dss.ivi.delivery.dto.fep.FeedStatusElement;
import com.mtvnet.dss.ivi.delivery.dto.fep.FepFeedsStatusResponse;
import com.mtvnet.dss.ivi.delivery.dto.ids.FeedEnvironment;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class FepFeedsStatusClientTest {

    private static final String PATH = "/feeds/status?json";
    private static final URL FEP_STATUS_URL;
    private static final FepFeedsStatusResponse FEEDS_STATUS_RESPONSE = new FepFeedsStatusResponse();
    private static final List<FeedStatusElement> FEED_STATUS_ELEMENTS = Collections.singletonList(
            new FeedStatusElement());

    static {
        try {
            FEP_STATUS_URL = new URL("http://localhost" + PATH);
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }
        FEEDS_STATUS_RESPONSE.setStatusList(FEED_STATUS_ELEMENTS);
    }

    @Mock
    private FepEnvironmentSpecificUrlBuilder environmentSpecificUrlBuilder;

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private FepFeedsStatusClient fepFeedsStatusClient;

    @Test
    public void shouldGetEnvironmentSpecificUrlAndQueryFepThroughRestTemplate() {
        ReflectionTestUtils.setField(fepFeedsStatusClient, "statusEndpointPath", PATH);
        when(environmentSpecificUrlBuilder.environmentSpecificFepUrl(FeedEnvironment.QA, PATH))
                .thenReturn(FEP_STATUS_URL);
        when(restTemplate.getForObject(FEP_STATUS_URL.toString(), FepFeedsStatusResponse.class))
                .thenReturn(FEEDS_STATUS_RESPONSE);

        List<FeedStatusElement> feedStatusElements = fepFeedsStatusClient.feedStatusListForFeedEnvironment(
                FeedEnvironment.QA);

        assertThat(feedStatusElements).isEqualTo(FEED_STATUS_ELEMENTS);
    }

}
