package com.mtvnet.dss.ivi.delivery.batch.implementation;

import com.mtvnet.dss.ivi.delivery.batch.implementation.marshalling.XmlRootToStringUnmarshaller;
import com.mtvnet.dss.ivi.delivery.dto.fep.BviVideoDocument;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.core.io.ClassPathResource;

import java.util.ArrayList;
import java.util.List;

import static com.mtvnet.dss.ivi.delivery.batch.BatchConfigurationConstants.IVI_XML_ITEM_NAME;
import static com.mtvnet.dss.ivi.delivery.batch.BatchConfigurationConstants.JOB_CONTEXT_TEMP_BVI_FILE_KEY;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.RETURNS_DEEP_STUBS;
import static org.mockito.BDDMockito.given;

public class BviItemReaderTest {

    private static final String FEP_FEED_LIST_CLASSPATH = "bviSample.xml";
    private static final int DOCUMENTS_AT_TEST_FEED = 5;
    private static final String[] DOCUMENT_IDS_AT_TEST_FEED = {
            "mgid:arc:video:mtv.com:b2143299-b614-4be9-9a12-b27093698dc1",
            "mgid:arc:video:mtv.com:b2143299-b614-4be9-9a12-b27093698dc2",
            "mgid:arc:video:mtv.com:b2143299-b614-4be9-9a12-b27093698dc3",
            "mgid:arc:video:mtv.com:b2143299-b614-4be9-9a12-b27093698dc4",
            "mgid:arc:video:mtv.com:b2143299-b614-4be9-9a12-b27093698dc5" };

    private BviItemReader reader = new BviItemReader();

    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
    }

    @Before
    public void setUp() throws Exception {
        reader.setUnmarshaller(new XmlRootToStringUnmarshaller());
        reader.setFragmentRootElementName(IVI_XML_ITEM_NAME);
    }

    @Test
    public void testDoRead() throws Exception {
        StepExecution stepExecution = Mockito.mock(StepExecution.class, RETURNS_DEEP_STUBS);
        given(stepExecution.getJobExecution().getExecutionContext().get(JOB_CONTEXT_TEMP_BVI_FILE_KEY))
                .willReturn(new ClassPathResource(FEP_FEED_LIST_CLASSPATH).getFile());

        reader.initBasedOnJobContext(stepExecution);
        reader.open(new ExecutionContext());
        List<BviVideoDocument> documents = new ArrayList<>(DOCUMENTS_AT_TEST_FEED);
        BviVideoDocument readItem;
        while ((readItem = reader.read()) != null) {
            documents.add(readItem);
        }
        reader.close();

        assertThat(documents.size()).isEqualTo(DOCUMENTS_AT_TEST_FEED);
        for (int i = 0; i < DOCUMENTS_AT_TEST_FEED; i++) {
            assertThat(DOCUMENT_IDS_AT_TEST_FEED[i]).isEqualTo(documents.get(i).getId());
        }
    }

}
