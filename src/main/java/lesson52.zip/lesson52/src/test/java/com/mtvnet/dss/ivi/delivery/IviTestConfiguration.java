package com.mtvnet.dss.ivi.delivery;

import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.test.context.ActiveProfiles;

@ActiveProfiles("test")
@TestConfiguration
public class IviTestConfiguration {
    //for future integration tests
}
